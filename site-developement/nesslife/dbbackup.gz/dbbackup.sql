#
# TABLE STRUCTURE FOR: api_key
#

DROP TABLE IF EXISTS `api_key`;

CREATE TABLE `api_key` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(40) NOT NULL,
  `level` int(2) NOT NULL,
  `ignore_limits` tinyint(1) NOT NULL DEFAULT '0',
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `ip_addresses` text,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: api_log
#

DROP TABLE IF EXISTS `api_log`;

CREATE TABLE `api_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `method` varchar(6) NOT NULL,
  `params` text,
  `api_key` varchar(40) NOT NULL,
  `date_log` datetime DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `authorized` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: article
#

DROP TABLE IF EXISTS `article`;

CREATE TABLE `article` (
  `id_article` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `author` varchar(55) DEFAULT NULL,
  `updater` varchar(55) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_off` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logical_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `indexed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `id_category` int(11) unsigned DEFAULT NULL,
  `comment_allow` char(1) DEFAULT '0',
  `comment_autovalid` char(1) DEFAULT '0',
  `comment_expire` datetime DEFAULT NULL,
  `flag` smallint(1) DEFAULT '0',
  `has_url` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `priority` smallint(1) unsigned NOT NULL DEFAULT '5',
  PRIMARY KEY (`id_article`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('1', '404', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', NULL, '0', '0', NULL, '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('2', '401', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', NULL, '0', '0', NULL, '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('3', '403', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', NULL, '0', '0', NULL, '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('4', 'welcome', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', NULL, '0', '0', NULL, '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('5', 'oznam-cafeteria', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 15:20:14', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 08:51:58', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('6', 'dobrovonicky-de-v-oaze', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 15:22:59', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 08:54:00', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('7', 'timesheets', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 11:42:13', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 11:46:36', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('8', 'garaz-na-bicykle', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 11:48:11', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 11:48:47', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('9', 'special-referral-fee', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 12:14:53', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 12:15:16', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('10', 'front-end-javascript-developer', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 13:03:28', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-29 13:28:15', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('11', 'c-senior-developer', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 13:05:59', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-29 13:45:57', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('12', 'oracle-database-specialist', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 13:07:13', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-29 13:45:49', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('13', 'python-developer', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 13:22:39', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-29 14:57:03', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('14', 'all-staff', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-26 08:26:49', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 08:27:13', '2015-05-28 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('15', 'pivo', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-26 08:27:29', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-01 13:03:41', '2015-05-24 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('16', 'oznam-cafeteria-2', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-26 08:52:09', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 08:52:52', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('17', 'solar', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-29 10:50:06', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-29 13:44:13', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('18', 'vix', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-29 10:50:24', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-29 13:44:21', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('19', 'perform', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-29 12:59:05', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-29 13:44:30', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('20', 'opera', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-29 13:00:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-29 13:44:38', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('21', 'ness', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-29 13:32:36', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-29 13:44:48', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('22', 'recruitment', 'marek.boros@ness.com', NULL, '2015-06-01 12:59:36', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-01 12:59:36', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('23', 'referral-fee', 'marek.boros@ness.com', NULL, '2015-06-01 13:00:59', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-01 13:00:59', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('24', 'vitajte-v-ness', 'marek.boros@ness.com', NULL, '2015-06-01 13:01:40', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-01 13:01:40', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('25', 'jaroslava-dermek', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-06-01 13:24:55', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-03 16:29:43', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('26', 'kristina-huncarova', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-06-01 13:33:22', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-03 14:46:38', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('27', 'dana-susterova', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-06-01 13:34:24', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-03 14:47:18', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('28', 'andrea-takacova', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-06-01 13:35:24', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-03 14:48:01', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('29', 'alena-stefanikova', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-06-01 13:38:15', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-04 08:28:03', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('30', 'chladnicky', 'marek.boros@ness.com', NULL, '2015-06-03 10:23:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-03 10:23:45', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('31', 'hr', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-06-04 14:58:33', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-04 15:24:25', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('32', 'zuzana-velesova', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-06-04 15:00:44', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-04 15:05:37', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('33', 'branislav-targos', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-06-04 15:11:37', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-04 15:12:32', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('34', 'lucia-beova', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-06-04 15:13:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-04 15:13:53', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('35', 'martina-bobikova', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-06-04 15:14:20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-04 15:15:18', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');


#
# TABLE STRUCTURE FOR: article_category
#

DROP TABLE IF EXISTS `article_category`;

CREATE TABLE `article_category` (
  `id_article` int(11) unsigned NOT NULL,
  `id_category` int(11) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `article_category` (`id_article`, `id_category`) VALUES ('7', '2');
INSERT INTO `article_category` (`id_article`, `id_category`) VALUES ('8', '5');
INSERT INTO `article_category` (`id_article`, `id_category`) VALUES ('9', '4');
INSERT INTO `article_category` (`id_article`, `id_category`) VALUES ('30', '2');


#
# TABLE STRUCTURE FOR: article_comment
#

DROP TABLE IF EXISTS `article_comment`;

CREATE TABLE `article_comment` (
  `id_article_comment` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_article` int(11) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `site` varchar(255) DEFAULT NULL,
  `content` text,
  `ip` varchar(40) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `admin` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'If comment comes from admin, set to 1',
  PRIMARY KEY (`id_article_comment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: article_lang
#

DROP TABLE IF EXISTS `article_lang`;

CREATE TABLE `article_lang` (
  `id_article` int(11) unsigned NOT NULL DEFAULT '0',
  `lang` varchar(8) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `content` longtext,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `online` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_article`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('1', 'sk', '404', '404', NULL, NULL, '<p>The content you asked for was not found !</p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('2', 'sk', '401', '401', 'Please login', NULL, '<p>Please login to see this content.</p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('3', 'sk', '403', '403', 'Forbidden', NULL, '<p>This content is forbidden.</p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('4', 'sk', 'welcome', 'Welcome', NULL, NULL, '<p>For more information about building a website with Ionize, you can:</p> <ul><li>Download & read <a href=\"http://www.ionizecms.com\">the Documentation</a></li><li>Visit <a href=\"http://www.ionizecms.com/forum\">the Community Forum</a></li></ul><p>Have fun !</p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('5', 'sk', 'oznam-cafeteria', 'Oznam: Cafeteria', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('6', 'sk', 'dobrovonicky-de-v-oaze', 'Dobrovoľnícky deň v Oáze', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('7', 'sk', 'timesheets', 'TIMESHEETS', '', '', '<p>Vyplň a releasni si svoj TMSH za obdobie 1.5.2015- 15.5.2015 /vrátane/ najneskôr 15.5.2015 do 10:00 hod</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('8', 'sk', 'garaz-na-bicykle', 'Garáž na bicykle', '', '', '<p>Zajtra t.j. 22.5.2015 prebehne vymena zamku na garazi kde sa odkladaju bicykle. Preto Vas poprosim, aby ste bicykle nedavali do garaze, je mozne si ich vziat do priestorov NESS KDC.</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('9', 'sk', 'special-referral-fee', 'SPECIAL REFERRAL FEE', '', '', '<p>Pošli nám tip na skúsených developerov a získaj atraktívnu odmenu - LEN DO KONCA MÁJA!</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('10', 'sk', 'front-end-javascript-developer', 'Front End Javascript Developer', '', '', '\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus volutpat ullamcorper porttitor. Sed molestie vitae ante eu semper. Vestibulum egestas odio et turpis vehicula, quis pharetra eros tempus. In id facilisis orci. Donec pellentesque non nulla a interdum. Sed mi risus, condimentum aliquam imperdiet ac, gravida vel ligula. Ut laoreet justo orci, nec commodo justo bibendum nec. Etiam molestie quam tincidunt orci pulvinar ornare. Nulla in efficitur orci, eget mattis diam. Nunc ut tempor magna, id blandit odio. Nullam ex erat, tempus et elementum fermentum, posuere ut lacus. Nullam et sollicitudin nulla, eu porta nunc. Aliquam vel nunc vel quam eleifend posuere vitae vitae nunc.</p>\n<h3><strong>Requirements</strong></h3>\n<ul>\n<li><strong>PHP</strong> - expert </li>\n<li><strong>HTML</strong> - expert </li>\n<li><strong>CSS</strong> - expert </li>\n<li><strong>Javascript</strong> - advanced</li>\n<li><strong>SQL</strong> - advanced</li>\n</ul>\n<h3><strong>Advantages</strong></h3>\n<ul>\n<li>PHP frameworks</li>\n<li>Knowledge about design patterns</li>\n<li>3 years of practice on this position</li>\n<li>Teamwork</li>\n</ul>\n', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('11', 'sk', 'c-senior-developer', 'c# Senior Developer', '', '', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus volutpat ullamcorper porttitor. Sed molestie vitae ante eu semper. Vestibulum egestas odio et turpis vehicula, quis pharetra eros tempus. In id facilisis orci. Donec pellentesque non nulla a interdum. Sed mi risus, condimentum aliquam imperdiet ac, gravida vel ligula. Ut laoreet justo orci, nec commodo justo bibendum nec. Etiam molestie quam tincidunt orci pulvinar ornare. Nulla in efficitur orci, eget mattis diam. Nunc ut tempor magna, id blandit odio. Nullam ex erat, tempus et elementum fermentum, posuere ut lacus. Nullam et sollicitudin nulla, eu porta nunc. Aliquam vel nunc vel quam eleifend posuere vitae vitae nunc.</p>\n<h3><strong>Requirements</strong></h3>\n<ul>\n<li><strong>PHP</strong> - expert </li>\n<li><strong>HTML</strong> - expert </li>\n<li><strong>CSS</strong> - expert </li>\n<li><strong>Javascript</strong> - advanced</li>\n<li><strong>SQL</strong> - advanced</li>\n</ul>\n<h3><strong>Advantages</strong></h3>\n<ul>\n<li>PHP frameworks</li>\n<li>Knowledge about design patterns</li>\n<li>3 years of practice on this position</li>\n<li>Teamwork</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('12', 'sk', 'oracle-database-specialist', 'Oracle Database Specialist', '', '', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus volutpat ullamcorper porttitor. Sed molestie vitae ante eu semper. Vestibulum egestas odio et turpis vehicula, quis pharetra eros tempus. In id facilisis orci. Donec pellentesque non nulla a interdum. Sed mi risus, condimentum aliquam imperdiet ac, gravida vel ligula. Ut laoreet justo orci, nec commodo justo bibendum nec. Etiam molestie quam tincidunt orci pulvinar ornare. Nulla in efficitur orci, eget mattis diam. Nunc ut tempor magna, id blandit odio. Nullam ex erat, tempus et elementum fermentum, posuere ut lacus. Nullam et sollicitudin nulla, eu porta nunc. Aliquam vel nunc vel quam eleifend posuere vitae vitae nunc.</p>\n<h3><strong>Requirements</strong></h3>\n<ul>\n<li><strong>PHP</strong> - expert </li>\n<li><strong>HTML</strong> - expert </li>\n<li><strong>CSS</strong> - expert </li>\n<li><strong>Javascript</strong> - advanced</li>\n<li><strong>SQL</strong> - advanced</li>\n</ul>\n<h3><strong>Advantages</strong></h3>\n<ul>\n<li>PHP frameworks</li>\n<li>Knowledge about design patterns</li>\n<li>3 years of practice on this position</li>\n<li>Teamwork</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('13', 'sk', 'python-academy', 'Python Academy', '', '', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus volutpat ullamcorper porttitor. Sed molestie vitae ante eu semper. Vestibulum egestas odio et turpis vehicula, quis pharetra eros tempus. In id facilisis orci. Donec pellentesque non nulla a interdum. Sed mi risus, condimentum aliquam imperdiet ac, gravida vel ligula. Ut laoreet justo orci, nec commodo justo bibendum nec. Etiam molestie quam tincidunt orci pulvinar ornare. Nulla in efficitur orci, eget mattis diam. Nunc ut tempor magna, id blandit odio. Nullam ex erat, tempus et elementum fermentum, posuere ut lacus. Nullam et sollicitudin nulla, eu porta nunc. Aliquam vel nunc vel quam eleifend posuere vitae vitae nunc.</p>\n<h3><strong>Requirements</strong></h3>\n<ul>\n<li><strong>PHP</strong> - expert </li>\n<li><strong>HTML</strong> - expert </li>\n<li><strong>CSS</strong> - expert </li>\n<li><strong>Javascript</strong> - advanced</li>\n<li><strong>SQL</strong> - advanced</li>\n</ul>\n<h3><strong>Advantages</strong></h3>\n<ul>\n<li>PHP frameworks</li>\n<li>Knowledge about design patterns</li>\n<li>3 years of practice on this position</li>\n<li>Teamwork</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('14', 'sk', 'all-staff', 'All staff', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('15', 'sk', 'pivo', 'Pivo', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('16', 'sk', 'oznam-cafeteria-2', 'Oznam: Cafeteria 2', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('17', 'sk', 'solar', 'Solar', '', '', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus volutpat ullamcorper porttitor. Sed molestie vitae ante eu semper. Vestibulum egestas odio et turpis vehicula, quis pharetra eros tempus. In id facilisis orci. Donec pellentesque non nulla a interdum. Sed mi risus, condimentum aliquam imperdiet ac, gravida vel ligula. Ut laoreet justo orci, nec commodo justo bibendum nec. Etiam molestie quam tincidunt orci pulvinar ornare. Nulla in efficitur orci, eget mattis diam. Nunc ut tempor magna, id blandit odio. Nullam ex erat, tempus et elementum fermentum, posuere ut lacus. Nullam et sollicitudin nulla, eu porta nunc. Aliquam vel nunc vel quam eleifend posuere vitae vitae nunc.</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('18', 'sk', 'vix', 'VIX', '', '', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus volutpat ullamcorper porttitor. Sed molestie vitae ante eu semper. Vestibulum egestas odio et turpis vehicula, quis pharetra eros tempus. In id facilisis orci. Donec pellentesque non nulla a interdum. Sed mi risus, condimentum aliquam imperdiet ac, gravida vel ligula. Ut laoreet justo orci, nec commodo justo bibendum nec. Etiam molestie quam tincidunt orci pulvinar ornare. Nulla in efficitur orci, eget mattis diam. Nunc ut tempor magna, id blandit odio. Nullam ex erat, tempus et elementum fermentum, posuere ut lacus. Nullam et sollicitudin nulla, eu porta nunc. Aliquam vel nunc vel quam eleifend posuere vitae vitae nunc.</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('19', 'sk', 'perform', 'Perform', '', '', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus volutpat ullamcorper porttitor. Sed molestie vitae ante eu semper. Vestibulum egestas odio et turpis vehicula, quis pharetra eros tempus. In id facilisis orci. Donec pellentesque non nulla a interdum. Sed mi risus, condimentum aliquam imperdiet ac, gravida vel ligula. Ut laoreet justo orci, nec commodo justo bibendum nec. Etiam molestie quam tincidunt orci pulvinar ornare. Nulla in efficitur orci, eget mattis diam. Nunc ut tempor magna, id blandit odio. Nullam ex erat, tempus et elementum fermentum, posuere ut lacus. Nullam et sollicitudin nulla, eu porta nunc. Aliquam vel nunc vel quam eleifend posuere vitae vitae nunc.</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('20', 'sk', 'opera', 'Opera', '', '', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus volutpat ullamcorper porttitor. Sed molestie vitae ante eu semper. Vestibulum egestas odio et turpis vehicula, quis pharetra eros tempus. In id facilisis orci. Donec pellentesque non nulla a interdum. Sed mi risus, condimentum aliquam imperdiet ac, gravida vel ligula. Ut laoreet justo orci, nec commodo justo bibendum nec. Etiam molestie quam tincidunt orci pulvinar ornare. Nulla in efficitur orci, eget mattis diam. Nunc ut tempor magna, id blandit odio. Nullam ex erat, tempus et elementum fermentum, posuere ut lacus. Nullam et sollicitudin nulla, eu porta nunc. Aliquam vel nunc vel quam eleifend posuere vitae vitae nunc.</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('21', 'sk', 'ness', 'Ness', '', '', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus volutpat ullamcorper porttitor. Sed molestie vitae ante eu semper. Vestibulum egestas odio et turpis vehicula, quis pharetra eros tempus. In id facilisis orci. Donec pellentesque non nulla a interdum. Sed mi risus, condimentum aliquam imperdiet ac, gravida vel ligula. Ut laoreet justo orci, nec commodo justo bibendum nec. Etiam molestie quam tincidunt orci pulvinar ornare. Nulla in efficitur orci, eget mattis diam. Nunc ut tempor magna, id blandit odio. Nullam ex erat, tempus et elementum fermentum, posuere ut lacus. Nullam et sollicitudin nulla, eu porta nunc. Aliquam vel nunc vel quam eleifend posuere vitae vitae nunc.</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('22', 'sk', 'recruitment', 'Recruitment', '', '', '<p>Oddelenie Recruitmentu, ktoré najdete na <b>6. poschodí č. miestnosti 733A, </b>sa zaoberá najmä hľadaním nových talentov, obsadzovaním volných pozícií a prijímaním nových zamestnancov.</p>\n<p>Kontaktujte nás na : <a href=\"mailto:Go2ness.ke@ness.com\">Go2ness.ke@ness.com</a></p>\n<p>Venujeme sa spracovávaniu profilov voľných pracovných pozícií, vyhľadávaniu vhodných kandidátov, organizácii a vedeniu výberových konaní, príprave pracovných zmlúv a ďalšiej súvisiacej administratívy, organizácii a vedeniu vstupných tréningov pre nových zamestancov, prezentácii spoločnosti na trhu práce</p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('23', 'sk', 'referral-fee', 'Referral fee', '', '', '<p>Účelom odmeny Referral fee (RF) je odmeniť súčasných zamestnancov spoločnosti NESS KDC za odporučenie a aktívnu spoluprácu pri nábore vhodných kandidátov</p>\n<p>na voľné pracovné pozície. Predpokladom je, že vhodní kandidáti zodpovedajú zadaným kritériám inzerovanej pozície, zamestnanci na nich vedia dať zodpovedajúce pracovné referencie, a kandidáti zároveň úspešne absolvujú výberový proces a uzatvoria hlavný pracovný pomer so spoločnosťou.</p>\n<p>Detailnejšie informácie nájdete v  smernici <a href=\"#\">Referral Fee</a></p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('24', 'sk', 'vitajte-v-ness', 'Vitajte v NESS', '', '', '<p>Prezentácia vstupný tréning</p>\n<p>BOZP prezentácia</p>\n<p>Interná dokumentácia (normy, smernice, template prelink)</p>\n<p>Zdravotná prehliadka (možnosti, kontakt na Luciu Beňovú, info ako prebieha + formulár na stiahnutie)</p>\n<p>Interné aplikácie (prelinky na Atandance, Timesheet, Vacation, Parking, Helpdesk)</p>\n<p>Benefity (štruktúra a prelink na HR + aplikaciu)</p>\n<p>Zľavy u obchodných partnerov (prelink na HR + aplikaciu)</p>\n<p>Noví zamestnanci (New Faces – prelink na foto a text o novonastupenych zamestnancoch / podla mesiacov)</p>\n<p>FAQ </p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('25', 'sk', 'jaroslava-dermek', 'Jaroslava Dermek', '', '', '<ul>\n<li>manažovanie a riadenie recruitment oddelenia</li>\n<li>implementácia a udržiavanie procesov v oblasti náboru zamestnancov</li>\n<li>riadenie a koordinovanie internej mobility a manazovanie Ness Academy a Bench strediska</li>\n<li>zabezpečenie a reprezentovanie spoločnosti na marketingových akciách podporujúcich nábor</li>\n<li>zodpovednosť a schvaľovanie publikovaných informácií o dianí v spoločnosti</li>\n<li>zabezpečovanie spolupráce s personálnymi agentúrami, analýzy</li>\n<li>štatistity a reporting  za oddelenie recruitmentu</li>\n<li>zodpovednosť za prehľad a uplatňenie voľných zdrojov v Ness KDC</li>\n<li>aktívna spolupráca pri obchodných aktivitách a nových oportunitách</li>\n<li>vyhľadávanie nových zdrojov pre získavanie nových zamestnancov</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('26', 'sk', 'kristina-huncarova', 'Kristína Hunčárová', '', '', '<ul>\n<li>zabezpečovanie procesu náboru z externých a interných zdrojov pre zákazníkov: CAPLIN, VIX, PERFORM</li>\n<li>zadávanie personálnej inzercie, vytváranie profilov pracovných pozícií</li>\n<li>priprava podkladov na publikáciu aktuálnych pracovných pozícií na interných obrazovkách spoločnosti</li>\n<li>príprava pracovných zmlúv a ďalšia súvisiaca administratíva</li>\n<li>organizácia a vedenie výberových konaní</li>\n<li>zastupovanie spoločnosti na marketingových akciách</li>\n<li>vstupné rozhovory so zamestnancami na zistenie ich spokojnosti</li>\n<li>reporting</li>\n<li>aktualizácia informácií pre účely publikácie na Facebook a Linked in za oblasť recruitmentu – zastúpenie</li>\n<li>organizačné zabezpečenie pri organizácií pracovných veľtrhov a príprave marketingových materiálov – zastúpenie</li>\n<li>publikácia „New Faces“ - neformálne predstavenie nových zamestnancov na internej stránke spoločnosti – zastúpenie</li>\n<li>zodpovednosť za aktualizáciu dát a nových podnetov na Ness KDC Website - zastúpenie</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('27', 'sk', 'dana-susterova', 'Dana Šusterová', '', '', '<ul>\n<li>zabezpečovanie procesu náboru z externých a interných zdrojov pre zákazníkov: ACTIMIZE, TRIBAL</li>\n<li>príprava pracovných zmlúv a ďalšia súvisiaca administratíva</li>\n<li>zadávanie personálnej inzercie, vytváranie profilov pracovných pozícií</li>\n<li>organizácia a vedenie výberových konaní</li>\n<li>aktualizácia informácií pre účely publikácie na Facebook a Linked in za oblasť recruitmentu</li>\n<li>zodpovednosť za aktualizáciu dát a nových podnetov na Ness KDC Website</li>\n<li>spolupráca a komunikácia s kandidátmi, externými inštitúciami a zamestnancami spoločnosti, poradenstvo vo zverenej oblasti</li>\n<li>zastupovanie spoločnosti na marketingových akciách</li>\n<li>vstupné rozhovory so zamestnancami na zistenie ich spokojnosti</li>\n<li>reporting</li>\n<li>priprava podkladov na publikáciu aktuálnych pracovných pozícií na interných obrazovkách spoločnosti – zastúpenie</li>\n<li>organizačné zabezpečenie Adaptačného procesu (Vstupný tréning zamestnancov, školenie BOZP, PO...) - zastúpenie</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('28', 'sk', 'andrea-takacova', 'Andrea Takáčová', '', '', '<ul>\n<li>zabezpečovanie procesu náboru z externých a interných zdrojov pre zákazníkov: SOLAR TURBINES, HERE, OPERA</li>\n<li>zadávanie personálnej inzercie, vytváranie profilov pracovných pozícií</li>\n<li>zodpovednosť za aktualizáciu dát a nových podnetov na Ness KDC Microsite</li>\n<li>publikácia „New Faces“ - neformálne predstavenie nových zamestnancov na internej stránke spoločnosti</li>\n<li>zadávanie personálnej inzercie, vytváranie profilov pracovných pozícií</li>\n<li>organizácia a vedenie výberových konaní</li>\n<li>príprava pracovných zmlúv a ďalšia súvisiaca administratíva</li>\n<li>organizačné zabezpečenie Adaptačného procesu (Vstupný tréning zamestnancov, školenie BOZP, PO...)</li>\n<li>vstupné rozhovory so zamestnancami na zistenie ich spokojnosti</li>\n<li>organizačné zabezpečenie pri organizácií pracovných veľtrhov a príprave marketingových materiálov</li>\n<li>zastupovanie spoločnosti na marketingových akciách</li>\n<li>reporting</li>\n<li>aktualizácia informácií pre účely publikácie na Facebook a Linked in za oblasť recruitmentu – zastúpenie</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('29', 'sk', 'alena-stefanikova', 'Alena Štefaniková', '', '', '<p>materská dovolenka</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('30', 'sk', 'chladnicky', 'Chladničky', '', '', '<p>Ahojte vsetci, dufam ze este stihame s chladnickovym emailom :D</p>\n<p>Chceme Vam popriat krasny vikend. Nech pocasie je super a zazijete skvele chvile s kamosmi, rodinkou alebo s kym chcete :D :D (nenapada ma s kym este :D)</p>\n<p> Tak klasika nezabudnite si Vase potraviny v chladnickach a vidiime sa ;)</p>\n<p> Prajem naozaj super vikend plny oddychuje a smiechu :P</p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('31', 'sk', 'hr', 'HR', 'S ľuďmi, o ľuďoch a pre ľudí :-)', '', '<p>HR oddelenie sa zaoberá starostlivosťou o existujúcich zamestnancov spoločnosti. Naším cieľom je byť rovnocenným partnerom a podporou pre každého jedného z Vás. Zaoberáme sa motiváciou a spokojnosťou zamestnancov, ktorú sa snažíme zvyšovať prostredníctvom rôznych programov v oblasti odmeňovania a benefitov, vzdelávania a rozvoja, kariérneho plánovania, spravodlivého hodnotenia a oceňovania pracovných úspechov. Súčasťou našej práce je aj administrácia a vedenie personálnej agendy.</p>\n<p><b>Činnosti a procesy v HR:</b></p>\n<ul>\n<li>Personálne plánovanie</li>\n<li>Analýza a tvorba pracovných pozícií vrátane popisov pracovných pozícií</li>\n<li>Podpora pri prijímaní a adaptácii zamestnancov</li>\n<li>Hodnotenie zamestnancov a riadenie výkonu</li>\n<li>Kariérne plánovanie (interné presuny, kariérny rast,...)</li>\n<li>Vzdelávanie a ďalší rozvoj zamestnancov</li>\n<li>Odmeňovanie a benefity</li>\n<li>Pracovno-právna agenda</li>\n<li>Pracovné vzťahy</li>\n<li>Spravovanie personálneho informačného systému</li>\n<li>Organizačné štruktúry</li>\n<li>Dochádzka a dochádzkový systém</li>\n<li>Analýzy a prieskumy trhu práce</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('32', 'sk', 'zuzana-velesova', 'Zuzana Velesová', '', '', '<p>Náplň práce:</p>\n<ul>\n<li>HR procesy a interná dokumentácia (vytváranie a aktualizácia)</li>\n<li>Tvorba, implementácia a vyhodnocovanie programov zameraných na motiváciu zamestnancov a zvyšovanie ich spokoujnosti</li>\n<li>HR plánovanie a analýzy (HR budget, headcount analýzy, motivačný program, odmeňovanie a benefity, vzdelávanie a rozvoj, hodnotenie zamestnancov, mzdové analýzy, rozbory seniority  a stability, fluktuácia a iné)</li>\n<li>Manažment pracovných vzťahov</li>\n<li>Podpora pri nových obchodných príležitostiach a nábore</li>\n<li>Koordinácia aktivít BOZP a PO a Pracovnej zdravotnej  služby</li>\n<li>Imigračná agenda (relokácie a transfery z/do NESS KDC)</li>\n<li>Programy oceňovania zamestnancov a ich mimoriadnych úspechov</li>\n<li>Korporátne HR projekty a aktivity (participácia na ich tvorbe, zodpovednosť za lokálnu implementáciu)</li>\n<li>Participácia pri organizácií praxe študentov, vedenie diplomových prác</li>\n<li>Komunikácia s externými inštitúciami (Úrad práce, Inšpektorát práce, Cudzinecká polícia,...)</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('33', 'sk', 'branislav-targos', 'Branislav Targoš', '', '', '<p>Náplň práce:</p>\n<ul>\n<li>Odmeňovanie a benefity (spolupráca pri tvorbe politiky odmeňovania a benefitov, príprava podkladov pre mzdové prieskumy, aktualizácia benefitov vrátane vrátane realizácie výberového procesu a jednaní s dodávateľmi, administrácia benefitového systému)</li>\n<li>Vedenie a kontrola mzdovej agendy (zmeny miezd, príprava podkladov na mzdy, komunikácia s externým poskytovateľom mzdových služieb)</li>\n<li>Podpora pri personálnej  agende (zadávanie a aktualizácia osobných údajov v interných aplikáciách, kontrola vykonaných zmien v pracovných pomeroch)</li>\n<li>Administrácia a kontrola dochádzky zamestnancov (riešenie problémov pri vykazovaní pracovnej doby)</li>\n<li>Tvorba a aktualizácia organizačnej štruktúry spoločnosti v SAPe</li>\n<li>Spolupráca a komunikácia s externými inštitúciami a zamestnancami spoločnosti, poradenstvo vo zverenej oblasti</li>\n<li>Spolupráca pri zabezpečnovaní  ďalších HR aktivít a projektov</li>\n<li>Predikcie miezd a ďalší reporting pre manažment spoločnosti, finančné oddelenie, ...</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('34', 'sk', 'lucia-beova', 'Lucia Beňová', '', '', '<p>Náplň práce:</p>\n<ul>\n<li>Vedenie personálnej agendy (príprava pracovných zmlúv, dodatkov, potvrdení pre zamestnancov, dokumentov pri skončení pracovného pomeru a ďalšia súvisiaca administratíva, zadávanie a aktualizácia osobných údajov v SAPe a interných aplikáciách)</li>\n<li>Vedenie mzdovej agendy (zmeny miezd, príprava podkladov na mzdy, komunikácia s externým poskytovateľom mzdových služieb)</li>\n<li>Administratívna a organizačná podpora pri imigračnom procese</li>\n<li>Vstupné a výstupné rozhovory so zamestnancami kvôli zisteniu ich spokojnosti</li>\n<li>Spolupráca s pracovnou zdravotnou službou a organizačné zabezpečenie lekárskych prehliadok</li>\n<li>Spolupráca a komunikácia s externými inštitúciami a zamestnancami spoločnosti, poradenstvo vo zverenej oblasti</li>\n<li>Spolupráca pri zabezpečnovaní ďalších HR aktivít a projektov</li>\n<li>Analýzy, štatistiky a reporting</li>\n</ul>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('35', 'sk', 'martina-bobikova', 'Martina Bobíková', '', '', '<p>Náplň práce:</p>\n<ul>\n<li>návrh a implementácia vzdelávacích a rozvojových programov pre zamestnancov</li>\n<li>návrh a implementácia procesov kariérneho plánovania a plánu nástupníctva</li>\n<li>príprava, zaškolenie, implementácia a monitorovanie hodnotiacich procesov zamestnancov</li>\n<li>zisťovanie vzdelávacích a rozvojových potrieb v spoločnosti a komunikácia s vedúcimi zamestnancami pri tvorbe tréningových a rozvojových plánov</li>\n<li>zabezpečovanie vzdelávacích a rozvojových aktivít prostredníctvom interných zdrojov a externých spoločností vrátane realizácie výberového procesu a jednaní s dodávateľmi</li>\n<li>hodnotenie implementovaných programov a sledovanie spätnej väzby na uskutočnené aktivity s cieľom skvalitniť poskytované služby pre potrebný rozvoj kvalifikácie zamestnancov</li>\n<li>sledovanie a analýza nákladov na vzdelávacie a rozvojové aktivity</li>\n<li>poskytovanie poradenstva pre riadiacich pracovníkov a zamestnancov v oblasti vzdelávania a rozvoja</li>\n<li>sledovanie a analýza trendov a noviniek na trhu vývoja vzdelávania a ďalšieho rozvoja zamestnancov a ich implementovanie podľa potreby</li>\n<li>spolupráca pri zabezpečnovaní ďalších HR aktivít a projektov</li>\n<li>analýzy, štatistiky a reporting</li>\n</ul>', '', '', '1');


#
# TABLE STRUCTURE FOR: article_media
#

DROP TABLE IF EXISTS `article_media`;

CREATE TABLE `article_media` (
  `id_article` int(11) unsigned NOT NULL DEFAULT '0',
  `id_media` int(11) unsigned NOT NULL DEFAULT '0',
  `online` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) unsigned DEFAULT '9999',
  `url` varchar(255) DEFAULT NULL,
  `lang_display` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id_article`,`id_media`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('5', '7', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('6', '9', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('16', '8', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('17', '12', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('18', '11', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('19', '13', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('20', '10', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('21', '14', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('25', '19', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('26', '15', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('27', '16', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('28', '17', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('29', '18', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('32', '20', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('33', '21', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('34', '22', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('35', '23', '1', '1', NULL, NULL);


#
# TABLE STRUCTURE FOR: article_tag
#

DROP TABLE IF EXISTS `article_tag`;

CREATE TABLE `article_tag` (
  `id_article` int(11) unsigned NOT NULL,
  `id_tag` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id_article`,`id_tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: article_type
#

DROP TABLE IF EXISTS `article_type`;

CREATE TABLE `article_type` (
  `id_type` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `ordering` int(11) DEFAULT '0',
  `description` text,
  `type_flag` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: captcha
#

DROP TABLE IF EXISTS `captcha`;

CREATE TABLE `captcha` (
  `id_captcha` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL DEFAULT '',
  `answer` varchar(255) NOT NULL DEFAULT '',
  `lang` varchar(8) NOT NULL DEFAULT '',
  `hash` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_captcha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id_category` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`id_category`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `category` (`id_category`, `name`, `ordering`) VALUES ('1', 'hr', '0');
INSERT INTO `category` (`id_category`, `name`, `ordering`) VALUES ('2', 'reception', '0');
INSERT INTO `category` (`id_category`, `name`, `ordering`) VALUES ('3', 'ito', '0');
INSERT INTO `category` (`id_category`, `name`, `ordering`) VALUES ('4', 'recruitment', '0');
INSERT INTO `category` (`id_category`, `name`, `ordering`) VALUES ('5', 'operations', '0');


#
# TABLE STRUCTURE FOR: category_lang
#

DROP TABLE IF EXISTS `category_lang`;

CREATE TABLE `category_lang` (
  `id_category` int(11) unsigned NOT NULL DEFAULT '0',
  `lang` varchar(8) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  PRIMARY KEY (`id_category`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `category_lang` (`id_category`, `lang`, `title`, `subtitle`, `description`) VALUES ('1', 'sk', 'HR', '', '');
INSERT INTO `category_lang` (`id_category`, `lang`, `title`, `subtitle`, `description`) VALUES ('2', 'sk', 'Reception', '', '');
INSERT INTO `category_lang` (`id_category`, `lang`, `title`, `subtitle`, `description`) VALUES ('3', 'sk', 'ITO', '', '');
INSERT INTO `category_lang` (`id_category`, `lang`, `title`, `subtitle`, `description`) VALUES ('4', 'sk', 'Recruitment', '', '');
INSERT INTO `category_lang` (`id_category`, `lang`, `title`, `subtitle`, `description`) VALUES ('5', 'sk', 'Operations', '', '');


#
# TABLE STRUCTURE FOR: element
#

DROP TABLE IF EXISTS `element`;

CREATE TABLE `element` (
  `id_element` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_element_definition` int(11) unsigned NOT NULL,
  `parent` varchar(50) NOT NULL,
  `id_parent` int(11) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_element`),
  KEY `idx_element_id_element_definition` (`id_element_definition`),
  KEY `idx_element_id_parent` (`id_parent`),
  KEY `idx_element_parent` (`parent`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('2', '2', 'article', '12', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('3', '2', 'article', '11', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('4', '2', 'article', '10', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('5', '2', 'article', '13', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('6', '3', 'article', '25', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('7', '3', 'article', '26', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('8', '3', 'article', '27', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('9', '3', 'article', '28', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('10', '3', 'article', '29', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('11', '3', 'article', '32', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('12', '3', 'article', '33', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('13', '3', 'article', '34', '1');
INSERT INTO `element` (`id_element`, `id_element_definition`, `parent`, `id_parent`, `ordering`) VALUES ('14', '3', 'article', '35', '1');


#
# TABLE STRUCTURE FOR: element_definition
#

DROP TABLE IF EXISTS `element_definition`;

CREATE TABLE `element_definition` (
  `id_element_definition` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text,
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_element_definition`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `element_definition` (`id_element_definition`, `name`, `description`, `ordering`) VALUES ('2', 'rcr-project', '', '0');
INSERT INTO `element_definition` (`id_element_definition`, `name`, `description`, `ordering`) VALUES ('3', 'team-member-info', '', '0');


#
# TABLE STRUCTURE FOR: element_definition_lang
#

DROP TABLE IF EXISTS `element_definition_lang`;

CREATE TABLE `element_definition_lang` (
  `id_element_definition` int(11) unsigned NOT NULL,
  `lang` varchar(8) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_element_definition`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `element_definition_lang` (`id_element_definition`, `lang`, `title`) VALUES ('2', 'sk', 'Project');
INSERT INTO `element_definition_lang` (`id_element_definition`, `lang`, `title`) VALUES ('3', 'sk', 'Memeber info');


#
# TABLE STRUCTURE FOR: event_log
#

DROP TABLE IF EXISTS `event_log`;

CREATE TABLE `event_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(50) DEFAULT NULL,
  `message` text,
  `id_user` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: extend_field
#

DROP TABLE IF EXISTS `extend_field`;

CREATE TABLE `extend_field` (
  `id_extend_field` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` int(3) unsigned NOT NULL,
  `description` varchar(255) DEFAULT '',
  `parent` varchar(50) NOT NULL,
  `id_parent` int(11) unsigned DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `translated` char(1) DEFAULT '0',
  `value` text,
  `default_value` varchar(255) DEFAULT NULL,
  `global` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `main` smallint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_extend_field`),
  KEY `idx_extend_field_parent` (`parent`),
  KEY `idx_extend_field_id_parent` (`id_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `extend_field` (`id_extend_field`, `name`, `type`, `description`, `parent`, `id_parent`, `ordering`, `translated`, `value`, `default_value`, `global`, `main`) VALUES ('1', 'rcr-position-project', '5', '', 'element', '2', '0', '0', '1:ness\n2:solar\n3:vix\n4:perform\n5:opera', '1', '0', '0');
INSERT INTO `extend_field` (`id_extend_field`, `name`, `type`, `description`, `parent`, `id_parent`, `ordering`, `translated`, `value`, `default_value`, `global`, `main`) VALUES ('2', 'position', '1', '', 'element', '3', '2', '0', '', '', '0', '0');
INSERT INTO `extend_field` (`id_extend_field`, `name`, `type`, `description`, `parent`, `id_parent`, `ordering`, `translated`, `value`, `default_value`, `global`, `main`) VALUES ('3', 'phone', '1', '', 'element', '3', '3', '0', '', 'klapka', '0', '0');
INSERT INTO `extend_field` (`id_extend_field`, `name`, `type`, `description`, `parent`, `id_parent`, `ordering`, `translated`, `value`, `default_value`, `global`, `main`) VALUES ('4', 'e-mail', '110', '', 'element', '3', '4', '0', '', '', '0', '0');
INSERT INTO `extend_field` (`id_extend_field`, `name`, `type`, `description`, `parent`, `id_parent`, `ordering`, `translated`, `value`, `default_value`, `global`, `main`) VALUES ('5', 'office', '1', '', 'element', '3', '1', '0', '', '6. poschodie, č. dverí 000', '0', '0');


#
# TABLE STRUCTURE FOR: extend_field_lang
#

DROP TABLE IF EXISTS `extend_field_lang`;

CREATE TABLE `extend_field_lang` (
  `id_extend_field` int(11) unsigned NOT NULL,
  `lang` varchar(8) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_extend_field`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `extend_field_lang` (`id_extend_field`, `lang`, `label`) VALUES ('1', 'sk', 'RCR-Position (project)');
INSERT INTO `extend_field_lang` (`id_extend_field`, `lang`, `label`) VALUES ('2', 'sk', 'Position');
INSERT INTO `extend_field_lang` (`id_extend_field`, `lang`, `label`) VALUES ('3', 'sk', 'Phone');
INSERT INTO `extend_field_lang` (`id_extend_field`, `lang`, `label`) VALUES ('4', 'sk', 'E-mail');
INSERT INTO `extend_field_lang` (`id_extend_field`, `lang`, `label`) VALUES ('5', 'sk', 'Office');


#
# TABLE STRUCTURE FOR: extend_field_type
#

DROP TABLE IF EXISTS `extend_field_type`;

CREATE TABLE `extend_field_type` (
  `id_extend_field_type` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) NOT NULL DEFAULT '',
  `default_values` smallint(1) NOT NULL DEFAULT '0',
  `values` smallint(1) NOT NULL DEFAULT '0',
  `translated` smallint(1) NOT NULL DEFAULT '0',
  `active` smallint(6) NOT NULL DEFAULT '1',
  `display` smallint(6) NOT NULL DEFAULT '1',
  `validate` varchar(50) DEFAULT NULL,
  `html_element` varchar(20) NOT NULL DEFAULT 'input',
  `html_element_type` varchar(20) NOT NULL DEFAULT 'text',
  `html_element_class` varchar(100) DEFAULT NULL,
  `html_element_pattern` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_extend_field_type`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8;

INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('1', 'Input', '1', '0', '1', '1', '1', NULL, 'input', 'text', 'w95p inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('2', 'Textarea', '1', '0', '1', '1', '1', NULL, 'textarea', 'textarea', 'w95p autogrow inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('3', 'Textarea + Editor', '1', '0', '1', '1', '1', NULL, 'textarea', 'editor', 'w95p smallTinyTextarea inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('4', 'Checkbox', '1', '1', '0', '1', '1', NULL, 'input', 'checkbox', 'checkbox', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('5', 'Radio', '1', '1', '0', '1', '1', NULL, 'input', 'radio', 'radio', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('6', 'Select', '1', '1', '0', '1', '1', NULL, 'input', 'select', 'select inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('7', 'Date Time', '0', '0', '0', '1', '1', NULL, 'input', 'date', 'date w120 inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('8', 'Medias', '0', '0', '1', '1', '1', NULL, 'div', 'media', NULL, NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('100', 'Number', '1', '0', '0', '1', '1', 'numeric', 'input', 'number', 'w120 inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('110', 'Email', '0', '0', '0', '1', '1', 'email', 'input', 'email', 'w95p inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('120', 'Phone', '0', '0', '0', '1', '1', 'digits', 'input', 'tel', 'w140 inputtext', '^((\\+\\d{1,3}(-| )?\\(?\\d\\)?(-| )?\\d{1,5})|(\\(?\\d{2,6}\\)?))(-| )?(\\d{3,4})(-| )?(\\d{4})(( x| ext)\\d{1,5}){0,1}$');
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('130', 'Internal Link', '0', '0', '1', '1', '1', NULL, 'div', 'link', 'droppable', NULL);


#
# TABLE STRUCTURE FOR: extend_fields
#

DROP TABLE IF EXISTS `extend_fields`;

CREATE TABLE `extend_fields` (
  `id_extend_fields` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_extend_field` int(11) unsigned NOT NULL,
  `parent` varchar(50) NOT NULL DEFAULT '',
  `id_parent` int(11) unsigned NOT NULL,
  `lang` varchar(8) NOT NULL DEFAULT '',
  `content` text,
  `ordering` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_extend_fields`),
  KEY `idx_extend_fields_id_parent` (`id_parent`),
  KEY `idx_extend_fields_lang` (`lang`),
  KEY `idx_extend_fields_id_extend_field` (`id_extend_field`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('2', '1', 'element', '2', '', '2', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('3', '1', 'element', '3', '', '3', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('4', '1', 'element', '4', '', '5', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('5', '1', 'element', '5', '', '1', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('6', '2', 'element', '6', '', 'Manager – Recruitment ', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('7', '3', 'element', '6', '', 'klapka 2066', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('8', '4', 'element', '6', '', 'Jaroslava.Dermek@ness.com', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('9', '2', 'element', '7', '', 'Execuive – Recruitment ', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('10', '3', 'element', '7', '', 'klapka 2033', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('11', '4', 'element', '7', '', 'Kristina.Huncarova@ness.com', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('12', '2', 'element', '8', '', 'Execuive – Recruitment', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('13', '3', 'element', '8', '', 'klapka 2240', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('14', '4', 'element', '8', '', 'Dana.Susterova@ness.com', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('15', '2', 'element', '9', '', 'Execuive – Recruitment', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('16', '3', 'element', '9', '', 'klapka 2351', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('17', '4', 'element', '9', '', 'Andrea.Takacova@ness.com', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('18', '2', 'element', '10', '', 'Execuive – Recruitment', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('19', '3', 'element', '10', '', 'materská dovolenka', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('20', '4', 'element', '10', '', '-', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('21', '2', 'element', '11', '', 'HR Manager', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('22', '3', 'element', '11', '', 'klapka 2071', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('23', '4', 'element', '11', '', 'Zuzana.Velesova@ness.com', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('24', '2', 'element', '12', '', 'Senior Executive - HR', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('25', '3', 'element', '12', '', 'klapka 2217', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('26', '4', 'element', '12', '', 'Branislav.Targos@ness.com', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('27', '2', 'element', '13', '', 'Executive - HR', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('28', '3', 'element', '13', '', 'klapka 2416', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('29', '4', 'element', '13', '', 'Lucia.Benova@ness.com', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('30', '2', 'element', '14', '', 'Executive - HR', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('31', '3', 'element', '14', '', 'klapka 2418', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('32', '4', 'element', '14', '', 'Martina.Bobikova@ness.com', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('33', '5', 'element', '11', '', '6. poschodie, č. dverí 747', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('34', '5', 'element', '12', '', '6. poschodie, č. dverí 747', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('35', '5', 'element', '13', '', '6. poschodie, č. dverí 747', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('36', '5', 'element', '14', '', '6. poschodie, č. dverí 747', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('37', '5', 'element', '6', '', '6. poschodie, č. dverí 733 A', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('38', '5', 'element', '7', '', '6. poschodie, č. dverí 733 A', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('39', '5', 'element', '8', '', '6. poschodie, č. dverí 733 A', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('40', '5', 'element', '9', '', '6. poschodie, č. dverí 733 A', '0');
INSERT INTO `extend_fields` (`id_extend_fields`, `id_extend_field`, `parent`, `id_parent`, `lang`, `content`, `ordering`) VALUES ('41', '5', 'element', '10', '', '6. poschodie, č. dverí 733 A', '0');


#
# TABLE STRUCTURE FOR: ion_sessions
#

DROP TABLE IF EXISTS `ion_sessions`;

CREATE TABLE `ion_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) DEFAULT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item
#

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `id_item` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_item_definition` int(10) unsigned NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `description` text,
  `ordering` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item instances';

#
# TABLE STRUCTURE FOR: item_definition
#

DROP TABLE IF EXISTS `item_definition`;

CREATE TABLE `item_definition` (
  `id_item_definition` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id_item_definition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Items definition table';

#
# TABLE STRUCTURE FOR: item_definition_lang
#

DROP TABLE IF EXISTS `item_definition_lang`;

CREATE TABLE `item_definition_lang` (
  `id_item_definition` int(11) unsigned NOT NULL,
  `lang` varchar(8) NOT NULL DEFAULT '',
  `title_definition` varchar(50) DEFAULT NULL,
  `title_item` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_item_definition`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item_lang
#

DROP TABLE IF EXISTS `item_lang`;

CREATE TABLE `item_lang` (
  `id_item` int(11) unsigned NOT NULL,
  `lang` varchar(8) NOT NULL DEFAULT '',
  `title` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_item`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS `items`;

CREATE TABLE `items` (
  `id_item` int(11) unsigned NOT NULL,
  `parent` varchar(50) NOT NULL DEFAULT '',
  `id_parent` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_item`,`parent`,`id_parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: lang
#

DROP TABLE IF EXISTS `lang`;

CREATE TABLE `lang` (
  `lang` varchar(8) NOT NULL DEFAULT '',
  `name` varchar(40) DEFAULT NULL,
  `online` char(1) DEFAULT '0',
  `def` char(1) DEFAULT '0',
  `ordering` int(11) DEFAULT NULL,
  `direction` smallint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `lang` (`lang`, `name`, `online`, `def`, `ordering`, `direction`) VALUES ('sk', 'slovak', '1', '1', '1', '1');


#
# TABLE STRUCTURE FOR: login_tracker
#

DROP TABLE IF EXISTS `login_tracker`;

CREATE TABLE `login_tracker` (
  `ip_address` varchar(32) NOT NULL,
  `first_time` int(11) unsigned NOT NULL,
  `failures` tinyint(2) unsigned DEFAULT NULL,
  PRIMARY KEY (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: media
#

DROP TABLE IF EXISTS `media`;

CREATE TABLE `media` (
  `id_media` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL DEFAULT '',
  `file_name` varchar(255) NOT NULL DEFAULT '' COMMENT 'file_name',
  `path` varchar(500) NOT NULL COMMENT 'Complete path to the medium, including media file name, excluding host name',
  `base_path` varchar(500) NOT NULL COMMENT 'medium folder base path, excluding host name',
  `copyright` varchar(128) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Medium date',
  `link` varchar(255) DEFAULT NULL COMMENT 'Link to a resource, attached to this medium',
  `square_crop` enum('tl','m','br') NOT NULL DEFAULT 'm',
  PRIMARY KEY (`id_media`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('1', 'picture', 'oznam.jpg', 'files/slideshow/oznam.jpg', 'files/slideshow/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('2', 'picture', 'oaza.jpg', 'files/slideshow/oaza.jpg', 'files/slideshow/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('3', 'picture', 'solar.png', 'files/projects/solar.png', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('4', 'picture', 'vix.png', 'files/projects/vix.png', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('5', 'picture', 'opera.png', 'files/projects/opera.png', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('6', 'picture', 'tribal.png', 'files/projects/tribal.png', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('7', 'picture', 'oznam2.jpg', 'files/slideshow/oznam2.jpg', 'files/slideshow/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('8', 'picture', 'oznam3.jpg', 'files/slideshow/oznam3.jpg', 'files/slideshow/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('9', 'picture', 'oaza2.jpg', 'files/slideshow/oaza2.jpg', 'files/slideshow/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('10', 'picture', 'Opera.jpg', 'files/projects/Opera.jpg', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('11', 'picture', 'vix.jpg', 'files/projects/vix.jpg', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('12', 'picture', 'solar.jpg', 'files/projects/solar.jpg', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('13', 'picture', 'perform.jpg', 'files/projects/perform.jpg', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('14', 'picture', 'ness.jpg', 'files/projects/ness.jpg', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('15', 'picture', 'rcr_kristina_hun_arova_recruitment_executive.jpg', 'files/faces/recruitment/rcr_kristina_hun_arova_recruitment_executive.jpg', 'files/faces/recruitment/', '', '', '0000-00-00 00:00:00', '', 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('16', 'picture', 'rcr_dana_susterova_recruitment_executive.jpg', 'files/faces/recruitment/rcr_dana_susterova_recruitment_executive.jpg', 'files/faces/recruitment/', '', '', '0000-00-00 00:00:00', '', 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('17', 'picture', 'rcr_andrea_taka_ova_recruitment_executive.jpg', 'files/faces/recruitment/rcr_andrea_taka_ova_recruitment_executive.jpg', 'files/faces/recruitment/', '', '', '0000-00-00 00:00:00', '', 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('18', 'picture', 'rcr_alena_stefanikova_recruitment_executive.jpg', 'files/faces/recruitment/rcr_alena_stefanikova_recruitment_executive.jpg', 'files/faces/recruitment/', '', '', '0000-00-00 00:00:00', '', 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('19', 'picture', 'rcr_jaroslava_dermek_recruitment_manager.jpg', 'files/faces/recruitment/rcr_jaroslava_dermek_recruitment_manager.jpg', 'files/faces/recruitment/', '', '', '0000-00-00 00:00:00', '', 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('20', 'picture', 'hr_zuzana_velesova_hr_manager.jpg', 'files/faces/hr/hr_zuzana_velesova_hr_manager.jpg', 'files/faces/hr/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('21', 'picture', 'hr_branislav_targos_senior_executive.jpg', 'files/faces/hr/hr_branislav_targos_senior_executive.jpg', 'files/faces/hr/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('22', 'picture', 'hr_lucia_be_ova_executive.jpg', 'files/faces/hr/hr_lucia_be_ova_executive.jpg', 'files/faces/hr/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('23', 'picture', 'hr_martina_bobikova_executive.jpg', 'files/faces/hr/hr_martina_bobikova_executive.jpg', 'files/faces/hr/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');


#
# TABLE STRUCTURE FOR: media_lang
#

DROP TABLE IF EXISTS `media_lang`;

CREATE TABLE `media_lang` (
  `lang` varchar(8) NOT NULL DEFAULT '',
  `id_media` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `alt` varchar(500) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`id_media`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `media_lang` (`lang`, `id_media`, `title`, `alt`, `description`) VALUES ('sk', '15', 'Krist&iacute;na Hunč&aacute;rov&aacute;', '', '');
INSERT INTO `media_lang` (`lang`, `id_media`, `title`, `alt`, `description`) VALUES ('sk', '16', 'Dana &Scaron;usterov&aacute;', '', '');
INSERT INTO `media_lang` (`lang`, `id_media`, `title`, `alt`, `description`) VALUES ('sk', '17', 'Andrea Tak&aacute;čov&aacute;', '', '');
INSERT INTO `media_lang` (`lang`, `id_media`, `title`, `alt`, `description`) VALUES ('sk', '18', 'Alena &Scaron;tefanikov&aacute;', '', '');
INSERT INTO `media_lang` (`lang`, `id_media`, `title`, `alt`, `description`) VALUES ('sk', '19', 'Jaroslava Dermek', '', '');


#
# TABLE STRUCTURE FOR: menu
#

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `ordering` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_menu`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `menu` (`id_menu`, `name`, `title`, `ordering`) VALUES ('1', 'main', 'Main menu', NULL);
INSERT INTO `menu` (`id_menu`, `name`, `title`, `ordering`) VALUES ('2', 'system', 'System menu', NULL);


#
# TABLE STRUCTURE FOR: module
#

DROP TABLE IF EXISTS `module`;

CREATE TABLE `module` (
  `id_module` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `with_admin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `version` varchar(10) NOT NULL DEFAULT '',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `info` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id_module`),
  KEY `i_module_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: module_setting
#

DROP TABLE IF EXISTS `module_setting`;

CREATE TABLE `module_setting` (
  `id_module_setting` int(11) NOT NULL AUTO_INCREMENT,
  `id_module` int(11) NOT NULL,
  `name` varchar(50) NOT NULL COMMENT 'Setting name',
  `content` varchar(255) NOT NULL COMMENT 'Setting content',
  `lang` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id_module_setting`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: note
#

DROP TABLE IF EXISTS `note`;

CREATE TABLE `note` (
  `id_note` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(10) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id_note`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: notification
#

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `id_notification` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date_creation` date DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `category` varchar(25) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` text,
  `read` smallint(1) DEFAULT '0',
  PRIMARY KEY (`id_notification`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `notification` (`id_notification`, `date_creation`, `code`, `category`, `title`, `content`, `read`) VALUES ('1', '2015-06-04', 'sitemap_refresh', 'System', 'Sitemap refresh', 'Sitemap needs to be refreshed.<br/> Go to <b>Tools > System Diagnosis > Tools</b> and click on <b>\"Refresh Sitemap\"</b>.', '0');


#
# TABLE STRUCTURE FOR: page
#

DROP TABLE IF EXISTS `page`;

CREATE TABLE `page` (
  `id_page` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_parent` int(11) unsigned NOT NULL DEFAULT '0',
  `id_menu` int(11) unsigned NOT NULL DEFAULT '0',
  `id_type` smallint(2) NOT NULL DEFAULT '0',
  `id_subnav` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `ordering` int(11) unsigned DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `online` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` tinyint(1) NOT NULL DEFAULT '0',
  `author` varchar(55) DEFAULT NULL,
  `updater` varchar(55) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_off` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logical_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `appears` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `has_url` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `view` varchar(50) DEFAULT NULL COMMENT 'Page view',
  `view_single` varchar(50) DEFAULT NULL COMMENT 'Single Article Page view',
  `article_list_view` varchar(50) DEFAULT NULL COMMENT 'Article list view for each article linked to this page',
  `article_view` varchar(50) DEFAULT NULL COMMENT 'Article detail view for each article linked to this page',
  `article_order` varchar(50) NOT NULL DEFAULT 'ordering' COMMENT 'Article order in this page. Can be "ordering", "date"',
  `article_order_direction` varchar(50) NOT NULL DEFAULT 'ASC',
  `link` varchar(255) DEFAULT '' COMMENT 'Link to internal / external resource',
  `link_type` varchar(25) DEFAULT NULL COMMENT '''page'', ''article'' or NULL',
  `link_id` varchar(20) NOT NULL DEFAULT '',
  `pagination` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Pagination use ?',
  `priority` int(1) unsigned NOT NULL DEFAULT '5' COMMENT 'Page priority',
  `used_by_module` tinyint(1) unsigned DEFAULT NULL,
  `deny_code` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id_page`),
  KEY `idx_page_id_parent` (`id_parent`),
  KEY `idx_page_level` (`level`),
  KEY `idx_page_menu` (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('1', '0', '2', '0', '0', '404', '0', '0', '1', '0', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', NULL, NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '0', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('2', '0', '2', '0', '0', '401', '0', '0', '1', '0', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', NULL, NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '0', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('3', '0', '2', '0', '0', '403', '0', '0', '1', '0', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', NULL, NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '0', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('4', '0', '1', '0', '0', 'home', '1', '0', '1', '1', NULL, 'marek.boros@ness.com', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-20 15:37:47', '0000-00-00 00:00:00', '1', '1', 'page_home', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('5', '15', '1', '0', '0', 'hr', '3', '1', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 14:47:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 10:34:02', '0000-00-00 00:00:00', '1', '1', '', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('6', '5', '1', '0', '0', 'nas-tim', '2', '2', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 14:51:42', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-04 15:06:05', '0000-00-00 00:00:00', '1', '1', 'page_team', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('7', '0', '2', '0', '0', 'slideshow', '1', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 15:18:41', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('8', '15', '1', '0', '0', 'recruitment', '4', '1', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 15:36:03', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 10:34:23', '0000-00-00 00:00:00', '1', '1', '', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('9', '15', '1', '0', '0', 'operations', '5', '1', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 15:36:16', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 10:35:24', '0000-00-00 00:00:00', '1', '1', '', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('10', '0', '1', '0', '0', 'forum', '4', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 15:36:33', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('11', '0', '1', '0', '0', 'aj-ty', '5', '0', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 15:36:49', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 10:54:51', '0000-00-00 00:00:00', '1', '1', '', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('12', '0', '1', '0', '0', 'dokumenty', '6', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 15:36:59', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('13', '0', '1', '0', '0', 'galerie', '7', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 15:37:08', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('14', '0', '1', '0', '0', 'kontakt', '8', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 15:37:19', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('15', '0', '1', '0', '0', 'backoffice', '3', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-22 10:33:36', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('16', '15', '1', '0', '0', 'finance', '11', '1', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-22 10:36:05', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('17', '9', '1', '0', '0', 'reception', '2', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-22 11:24:09', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('18', '9', '1', '0', '0', 'travel', '3', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-22 11:24:28', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('19', '9', '1', '0', '0', 'ito', '6', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-22 11:24:40', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('20', '8', '1', '0', '0', 'vone-pozicie', '2', '2', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 11:31:38', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-29 11:24:47', '0000-00-00 00:00:00', '1', '1', 'page_rcr_positions', 'page_rcr_single_position', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('21', '0', '1', '0', '0', 'news', '2', '0', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 11:34:11', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-28 15:19:47', '0000-00-00 00:00:00', '1', '1', 'page_news', 'page_news_single_article', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('22', '9', '1', '0', '0', 'team', '1', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:45:50', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('23', '9', '1', '0', '0', 'purchasing', '4', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:46:23', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('24', '9', '1', '0', '0', 'logistics', '5', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:47:05', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('25', '8', '1', '0', '0', 'team-1', '1', '2', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-25 14:49:48', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-06-01 15:02:51', '0000-00-00 00:00:00', '1', '1', 'page_team', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('26', '8', '1', '0', '0', 'referral-fee', '12', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:50:20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('27', '8', '1', '0', '0', 'vitajte-v-ness', '13', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:50:42', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('28', '0', '2', '0', '0', 'events', '2', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-26 08:24:22', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('29', '0', '2', '0', '0', 'labs', '3', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-29 10:46:59', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('31', '5', '1', '0', '0', 'ocenenia', '14', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-06-04 16:03:48', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);


#
# TABLE STRUCTURE FOR: page_article
#

DROP TABLE IF EXISTS `page_article`;

CREATE TABLE `page_article` (
  `id_page` int(11) unsigned NOT NULL,
  `id_article` int(11) unsigned NOT NULL,
  `online` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `view` varchar(50) DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `id_type` int(11) unsigned DEFAULT NULL,
  `link_type` varchar(25) NOT NULL DEFAULT '',
  `link_id` varchar(20) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `main_parent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_page`,`id_article`),
  KEY `idx_page_article_id_type` (`id_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('1', '1', '1', NULL, '0', NULL, '', '', '', '0');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('2', '2', '1', NULL, '0', NULL, '', '', '', '0');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('3', '3', '1', NULL, '0', NULL, '', '', '', '0');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('4', '4', '1', NULL, '0', NULL, '', '', '', '0');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('5', '31', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('6', '32', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('6', '33', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('6', '34', '1', NULL, '3', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('6', '35', '1', NULL, '4', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('7', '5', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('7', '6', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('7', '16', '1', NULL, '3', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('8', '22', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('20', '10', '1', NULL, '3', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('20', '11', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('20', '12', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('20', '13', '1', NULL, '4', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('21', '7', '1', NULL, '4', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('21', '8', '1', NULL, '3', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('21', '9', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('21', '30', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('25', '25', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('25', '26', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('25', '27', '1', NULL, '3', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('25', '28', '1', NULL, '4', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('25', '29', '1', NULL, '5', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('26', '23', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('27', '24', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('28', '14', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('28', '15', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('29', '17', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('29', '18', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('29', '19', '1', NULL, '3', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('29', '20', '1', NULL, '4', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('29', '21', '1', NULL, '5', NULL, '', '', '', '1');


#
# TABLE STRUCTURE FOR: page_lang
#

DROP TABLE IF EXISTS `page_lang`;

CREATE TABLE `page_lang` (
  `lang` varchar(8) NOT NULL DEFAULT '',
  `id_page` int(11) unsigned NOT NULL DEFAULT '0',
  `url` varchar(100) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `subnav_title` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `online` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_page`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '1', '404', '', '404', 'Can\'t find requested page.', '', '', NULL, NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '2', '401', '', '401', 'Login needed', '', '', NULL, NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '3', '403', '', '403', 'Forbidden', '', '', NULL, NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '4', 'home', '', 'Home', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '5', 'hr', '', 'HR', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '6', 'team', '', 'Team', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '7', 'slideshow', '', 'SlideShow', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '8', 'recruitment', '', 'Recruitment', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '9', 'operations', '', 'Operations', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '10', 'forum', '', 'Fórum', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '11', 'aj-ty', '', 'A:J TY', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '12', 'dokumenty', '', 'Dokumenty', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '13', 'galerie', '', 'Galérie', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '14', 'kontakt', '', 'Kontakt', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '15', 'backoffice', '', 'BackOffice', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '16', 'finance', '', 'Finance', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '17', 'reception', '', 'Reception', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '18', 'travel', '', 'Travel', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '19', 'ito', '', 'ITO', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '20', 'volne-pozicie', '', 'Pozície', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '21', 'news', '', 'News', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '22', 'team', '', 'Team', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '23', 'purchasing', '', 'Purchasing', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '24', 'logistics', '', 'Logistics', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '25', 'team', '', 'Team', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '26', 'referral-fee', '', 'Referral fee', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '27', 'vitajte-v-ness', '', 'Vitajte v Ness', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '28', 'events', '', 'Events', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '29', 'labs', '', 'Labs', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '31', 'ocenenia', '', 'Ocenenia', '', '', '', '', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: page_media
#

DROP TABLE IF EXISTS `page_media`;

CREATE TABLE `page_media` (
  `id_page` int(11) unsigned NOT NULL DEFAULT '0',
  `id_media` int(11) unsigned NOT NULL DEFAULT '0',
  `online` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) unsigned DEFAULT '9999',
  `lang_display` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id_page`,`id_media`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: resource
#

DROP TABLE IF EXISTS `resource`;

CREATE TABLE `resource` (
  `id_resource` int(11) NOT NULL AUTO_INCREMENT,
  `id_parent` int(11) unsigned DEFAULT NULL,
  `resource` varchar(255) NOT NULL DEFAULT '',
  `actions` varchar(500) DEFAULT '',
  `title` varchar(255) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  PRIMARY KEY (`id_resource`),
  UNIQUE KEY `resource_key` (`resource`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8;

INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('1', NULL, 'admin', '', 'Backend login', 'Connect to ionize backend');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('10', NULL, 'admin/menu', 'create,edit,delete', 'Menu', 'Menus');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('11', '10', 'admin/menu/permissions/backend', '', 'Permissions', 'Menu > Backend Permissions');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('20', NULL, 'admin/translations', '', 'Translations', 'Translations');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('30', NULL, 'admin/filemanager', 'upload,rename,delete,move', 'Filemanager', 'FileManager');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('35', NULL, 'admin/medialist', '', 'MediaList', 'MediaList');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('40', NULL, 'admin/page', 'create,edit,delete', 'Page', 'Page');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('41', '40', 'admin/page/article', 'add', 'Article', 'Page > Article');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('42', '40', 'admin/page/element', 'add', 'Content Element', 'Page > Content Element');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('50', '40', 'admin/page/media', 'link,unlink,edit', 'Media', 'Page > Media');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('60', '40', 'admin/page/permissions', '', 'Permission', 'Page > Permission');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('61', '60', 'admin/page/permissions/backend', '', 'Backend', 'Page > Permission > Backend');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('62', '60', 'admin/page/permissions/frontend', '', 'Frontend', 'Page > Permission > Frontend');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('70', NULL, 'admin/article', 'create,edit,delete,move,copy,duplicate', 'Article', 'Article');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('80', '70', 'admin/article/media', 'link,unlink,edit', 'Media', 'Article > Media');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('85', '70', 'admin/article/element', 'add', 'Content Element', 'Article > Content Element');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('86', '70', 'admin/article/category', '', 'Manage categories', 'Article > Categories');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('90', '70', 'admin/article/permissions', '', 'Permission', 'Article > Permission');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('91', '90', 'admin/article/permissions/backend', '', 'Backend', 'Article > Permission > Backend');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('92', '90', 'admin/article/permissions/frontend', '', 'Frontend', 'Article > Permission > Frontend');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('93', '70', 'admin/article/tag', '', 'Manage tags', 'Article > Tags');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('100', NULL, 'admin/tree', '', 'Tree', '');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('101', '100', 'admin/tree/menu', 'add_page,edit', 'Menus', '');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('102', '100', 'admin/tree/page', 'status,add_page,add_article,order', 'Pages', '');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('103', '100', 'admin/tree/article', 'unlink,status,move,copy,order', 'Articles', '');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('120', NULL, 'admin/article/type', 'create,edit,delete', 'Article Type', 'Article types');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('150', NULL, 'admin/modules', 'install', 'Modules', 'Modules');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('151', '150', 'admin/modules/permissions', '', 'Set Permissions', 'Modules > Permissions');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('180', NULL, 'admin/element', 'create,edit,delete', 'Content Element', 'Content Elements');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('181', '180', 'admin/element/media', 'link,unlink,edit', 'Media', 'Content Elements > Media');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('210', NULL, 'admin/extend', 'create,edit,delete', 'Extend Fields', 'Extend Fields');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('220', NULL, 'admin/item', 'create,edit,delete,add', 'Static Items', 'Static Items');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('221', '220', 'admin/item/definition', 'edit', 'Definition', 'Static Items > Definition');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('222', '220', 'admin/item/media', 'link,unlink,edit', 'Media', 'Static Items > Media');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('240', NULL, 'admin/tools', '', 'Tools', 'Tools');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('241', '240', 'admin/tools/google_analytics', '', 'Google Analytics', 'Tools > Google Analytics');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('250', '240', 'admin/tools/system', '', 'System Diagnosis', 'Tools > System');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('251', '250', 'admin/tools/system/information', '', 'Information', 'Tools > System > Information');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('252', '250', 'admin/tools/system/repair', '', 'Repair tools', 'Tools > System > Repair');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('253', '250', 'admin/tools/system/report', '', 'Reports', 'Tools > System > Reports');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('270', NULL, 'admin/settings', '', 'Settings', 'Settings');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('271', '270', 'admin/settings/ionize', '', 'Ionize UI', 'Settings > UI Settings');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('272', '270', 'admin/settings/languages', '', 'Languages Management', 'Settings > Languages');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('273', '270', 'admin/settings/themes', 'edit', 'Themes', 'Settings > Themes');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('274', '270', 'admin/settings/website', '', 'Website settings', 'Settings > Website');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('275', '270', 'admin/settings/technical', '', 'Technical settings', 'Settings > Technical');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('300', NULL, 'admin/users_roles', '', 'Users / Roles', 'Users / Roles');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('301', '300', 'admin/user', 'create,edit,delete', 'Users', 'Users');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('302', '300', 'admin/role', 'create,edit,delete', 'Roles', 'Roles');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('303', '302', 'admin/role/permissions', '', 'Set Permissions', 'See Role\'s permissions');


#
# TABLE STRUCTURE FOR: role
#

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `id_role` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `role_level` int(11) DEFAULT NULL,
  `role_code` varchar(25) NOT NULL,
  `role_name` varchar(100) NOT NULL,
  `role_description` tinytext,
  PRIMARY KEY (`id_role`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('1', '10000', 'super-admin', 'Super Admin', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('2', '5000', 'admin', 'Admin', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('3', '1000', 'editor', 'Editor', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('4', '100', 'user', 'User', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('5', '50', 'pending', 'Pending', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('6', '10', 'guest', 'Guest', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('7', '-10', 'banned', 'Banned', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('8', '-100', 'deactivated', 'Deactivated', '');


#
# TABLE STRUCTURE FOR: rule
#

DROP TABLE IF EXISTS `rule`;

CREATE TABLE `rule` (
  `id_role` int(11) NOT NULL,
  `resource` varchar(100) NOT NULL DEFAULT '',
  `actions` varchar(100) NOT NULL DEFAULT '',
  `permission` smallint(1) DEFAULT NULL,
  `id_element` int(11) unsigned DEFAULT NULL,
  `id_user` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_role`,`resource`,`actions`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('1', 'all', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article', 'create,edit,delete,move,copy,duplicate', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/category', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/element', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/permissions/backend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/permissions/frontend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/tag', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/type', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/element', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/element/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/extend', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/filemanager', 'upload,rename,delete,move', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/item', 'create,edit,delete,add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/item/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/medialist', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/menu', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/modules', 'install', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/modules/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/article', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/element', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/permissions/backend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/permissions/frontend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/role', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/role/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/settings', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/settings/ionize', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/settings/languages', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/settings/website', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools/google_analytics', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools/system', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools/system/information', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools/system/repair', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools/system/report', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/translations', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tree', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tree/article', 'unlink,status,move,copy,order', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tree/menu', 'add_page,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tree/page', 'status,add_page,add_article,order', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/user', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/users_roles', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article', 'create,edit,delete,move,copy,duplicate', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/category', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/element', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/permissions/backend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/permissions/frontend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/tag', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/element/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/filemanager', 'upload,rename,delete,move', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/item', 'create,edit,delete,add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/item/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/medialist', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/menu', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/modules', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/article', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/element', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/permissions/backend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/permissions/frontend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/settings', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/settings/ionize', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/settings/languages', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/settings/website', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tools', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tools/google_analytics', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tools/system', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tools/system/information', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tools/system/report', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/translations', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tree', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tree/article', 'unlink,status,move,copy,order', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tree/menu', 'add_page,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tree/page', 'status,add_page,add_article,order', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/user', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/users_roles', '', '1', NULL, '0');


#
# TABLE STRUCTURE FOR: setting
#

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `id_setting` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `lang` varchar(8) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_setting`),
  UNIQUE KEY `idx_unq_setting` (`name`,`lang`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('1', 'ionize_version', '1.0.7', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('2', 'site_email', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('3', 'files_path', 'files', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('4', 'theme', 'nesslife', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('5', 'theme_admin', 'admin', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('6', 'google_analytics', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('7', 'filemanager', 'mootools-filemanager', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('8', 'show_help_tips', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('9', 'display_connected_label', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('10', 'display_dashboard_shortcuts', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('11', 'display_dashboard_modules', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('12', 'display_dashboard_users', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('13', 'display_dashboard_content', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('14', 'display_front_offline_content', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('15', 'display_dashboard_quick_settings', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('16', 'texteditor', 'tinymce', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('17', 'media_thumb_size', '120', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('18', 'tinybuttons1', 'pdw_toggle,|,bold,italic,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,formatselect,|,bullist,numlist,|,link,unlink,image,|,spellchecker', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('19', 'tinybuttons2', 'fullscreen, undo,redo,|,pastetext,selectall,removeformat,|,media,charmap,hr,blockquote,|,template,|,codemirror', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('20', 'tinybuttons3', 'tablecontrols', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('21', 'smalltinybuttons1', 'bold,italic,|,bullist,numlist,|,link,unlink,image,|,nonbreaking', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('22', 'smalltinybuttons2', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('23', 'smalltinybuttons3', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('24', 'displayed_admin_languages', 'en', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('25', 'date_format', '%Y.%m.%d', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('26', 'force_lang_urls', '0', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('27', 'tinyblockformats', 'p,h2,h3,h4,h5,pre,div', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('28', 'article_allowed_tags', 'h2,h3,h4,h5,h6,em,img,iframe,table,object,thead,tbody,tfoot,tr,th,td,param,embed,map,p,a,ul,ol,li,br,b,strong', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('29', 'filemanager_file_types', 'gif,jpe,jpeg,jpg,png,flv,mpeg,mpg,mp3,pdf', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('30', 'default_admin_lang', 'en', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('31', 'upload_autostart', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('32', 'resize_on_upload', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('33', 'picture_max_width', '1200', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('34', 'picture_max_height', '1200', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('35', 'upload_mode', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('36', 'no_source_picture', 'default.png', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('37', 'enable_backend_tracker', '0', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('38', 'backend_ui_style', 'original', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('39', 'notification', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('40', 'notification_date', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('41', 'site_title', 'My website', 'sk');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('42', 'last_notification_refresh', '2015-06-04 08:27:29', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('43', 'last_version', '1.0.7', '');


#
# TABLE STRUCTURE FOR: tag
#

DROP TABLE IF EXISTS `tag`;

CREATE TABLE `tag` (
  `id_tag` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tracker
#

DROP TABLE IF EXISTS `tracker`;

CREATE TABLE `tracker` (
  `id_user` int(11) unsigned NOT NULL,
  `ip_address` varchar(32) DEFAULT NULL,
  `element` varchar(50) DEFAULT NULL,
  `id_element` int(11) DEFAULT NULL,
  `last_time` datetime DEFAULT NULL,
  `elements` varchar(3000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: type
#

DROP TABLE IF EXISTS `type`;

CREATE TABLE `type` (
  `id_type` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `parent` char(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(3000) DEFAULT NULL,
  `ordering` smallint(6) NOT NULL,
  `view` varchar(50) DEFAULT NULL COMMENT 'view',
  `flag` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ui_element
#

DROP TABLE IF EXISTS `ui_element`;

CREATE TABLE `ui_element` (
  `id_ui_element` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_company` int(11) unsigned DEFAULT NULL,
  `type` enum('tab','table','list') DEFAULT NULL,
  `panel` varchar(25) DEFAULT NULL COMMENT 'UI context',
  `title` varchar(50) DEFAULT NULL,
  `ordering` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_ui_element`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ui_element_lk_extend
#

DROP TABLE IF EXISTS `ui_element_lk_extend`;

CREATE TABLE `ui_element_lk_extend` (
  `id_ui_element` int(11) unsigned NOT NULL,
  `id_extend` int(11) NOT NULL DEFAULT '0',
  `ordering` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_ui_element`,`id_extend`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: url
#

DROP TABLE IF EXISTS `url`;

CREATE TABLE `url` (
  `id_url` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_entity` int(11) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `canonical` smallint(1) NOT NULL DEFAULT '0',
  `active` smallint(1) NOT NULL DEFAULT '0',
  `lang` varchar(8) NOT NULL,
  `path` varchar(255) NOT NULL DEFAULT '',
  `path_ids` varchar(50) DEFAULT NULL,
  `full_path_ids` varchar(50) DEFAULT NULL,
  `creation_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_url`),
  KEY `idx_url_type` (`type`),
  KEY `idx_url_active` (`active`),
  KEY `idx_url_lang` (`lang`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;

INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('4', '7', 'page', '1', '1', 'sk', 'slideshow', '7', '7', '2015-05-20 15:18:41');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('5', '5', 'article', '1', '1', 'sk', 'slideshow/oznam-cafeteria', '7/5', '7/5', '2015-05-20 15:20:14');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('6', '6', 'article', '1', '1', 'sk', 'slideshow/dobrovonicky-de-v-oaze', '7/6', '7/6', '2015-05-20 15:22:59');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('9', '10', 'page', '1', '1', 'sk', 'forum', '10', '10', '2015-05-20 15:36:33');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('11', '12', 'page', '1', '1', 'sk', 'dokumenty', '12', '12', '2015-05-20 15:36:59');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('12', '13', 'page', '1', '1', 'sk', 'galerie', '13', '13', '2015-05-20 15:37:08');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('13', '14', 'page', '1', '1', 'sk', 'kontakt', '14', '14', '2015-05-20 15:37:20');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('14', '4', 'page', '1', '1', 'sk', 'home', '4', '4', '2015-05-20 15:37:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('15', '15', 'page', '1', '1', 'sk', 'backoffice', '15', '15', '2015-05-22 10:33:37');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('16', '5', 'page', '1', '1', 'sk', 'backoffice/hr', '15/5', '15/5', '2015-05-22 10:34:02');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('18', '8', 'page', '1', '1', 'sk', 'backoffice/recruitment', '15/8', '15/8', '2015-05-22 10:34:24');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('19', '9', 'page', '1', '1', 'sk', 'backoffice/operations', '15/9', '15/9', '2015-05-22 10:35:24');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('20', '16', 'page', '1', '1', 'sk', 'backoffice/finance', '15/16', '15/16', '2015-05-22 10:36:05');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('21', '17', 'page', '1', '1', 'sk', 'backoffice/operations/reception', '15/9/17', '15/9/17', '2015-05-22 11:24:09');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('22', '18', 'page', '1', '1', 'sk', 'backoffice/operations/travel', '15/9/18', '15/9/18', '2015-05-22 11:24:29');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('23', '19', 'page', '1', '1', 'sk', 'backoffice/operations/ito', '15/9/19', '15/9/19', '2015-05-22 11:24:40');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('37', '22', 'page', '1', '1', 'sk', 'backoffice/operations/team', '15/9/22', '15/9/22', '2015-05-25 14:45:50');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('38', '23', 'page', '1', '1', 'sk', 'backoffice/operations/purchasing', '15/9/23', '15/9/23', '2015-05-25 14:46:24');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('39', '24', 'page', '1', '1', 'sk', 'backoffice/operations/logistics', '15/9/24', '15/9/24', '2015-05-25 14:47:06');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('46', '26', 'page', '1', '1', 'sk', 'backoffice/recruitment/referral-fee', '15/8/26', '15/8/26', '2015-05-25 14:50:20');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('47', '27', 'page', '1', '1', 'sk', 'backoffice/recruitment/vitajte-v-ness', '15/8/27', '15/8/27', '2015-05-25 14:50:42');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('48', '28', 'page', '1', '1', 'sk', 'events', '28', '28', '2015-05-26 08:24:22');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('49', '14', 'article', '1', '1', 'sk', 'events/all-staff', '28/14', '28/14', '2015-05-26 08:26:49');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('50', '15', 'article', '1', '1', 'sk', 'events/pivo', '28/15', '28/15', '2015-05-26 08:27:29');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('51', '16', 'article', '1', '1', 'sk', 'slideshow/oznam-cafeteria-2', '7/16', '7/16', '2015-05-26 08:52:10');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('53', '11', 'page', '1', '1', 'sk', 'aj-ty', '11', '11', '2015-05-26 10:54:51');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('63', '21', 'page', '1', '1', 'sk', 'news', '21', '21', '2015-05-28 15:19:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('64', '7', 'article', '1', '1', 'sk', 'news/timesheets', '21/7', '21/7', '2015-05-28 15:19:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('65', '8', 'article', '1', '1', 'sk', 'news/garaz-na-bicykle', '21/8', '21/8', '2015-05-28 15:19:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('66', '9', 'article', '1', '1', 'sk', 'news/special-referral-fee', '21/9', '21/9', '2015-05-28 15:19:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('67', '29', 'page', '1', '1', 'sk', 'labs', '29', '29', '2015-05-29 10:46:59');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('68', '17', 'article', '1', '1', 'sk', 'labs/solar', '29/17', '29/17', '2015-05-29 10:50:07');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('69', '18', 'article', '1', '1', 'sk', 'labs/vix', '29/18', '29/18', '2015-05-29 10:50:24');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('70', '20', 'page', '1', '1', 'sk', 'backoffice/recruitment/volne-pozicie', '15/8/20', '15/8/20', '2015-05-29 11:24:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('71', '10', 'article', '1', '1', 'sk', 'backoffice/recruitment/volne-pozicie/front-end-javascript-developer', '15/8/20/10', '15/8/20/10', '2015-05-29 11:24:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('72', '11', 'article', '1', '1', 'sk', 'backoffice/recruitment/volne-pozicie/c-senior-developer', '15/8/20/11', '15/8/20/11', '2015-05-29 11:24:48');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('73', '12', 'article', '1', '1', 'sk', 'backoffice/recruitment/volne-pozicie/oracle-database-specialist', '15/8/20/12', '15/8/20/12', '2015-05-29 11:24:48');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('74', '13', 'article', '1', '0', 'sk', 'backoffice/recruitment/volne-pozicie/python-developer', '15/8/20/13', '15/8/20/13', '2015-05-29 11:24:48');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('75', '19', 'article', '1', '1', 'sk', 'labs/perform', '29/19', '29/19', '2015-05-29 12:59:05');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('76', '20', 'article', '1', '1', 'sk', 'labs/opera', '29/20', '29/20', '2015-05-29 13:00:01');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('77', '21', 'article', '1', '1', 'sk', 'labs/ness', '29/21', '29/21', '2015-05-29 13:32:36');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('78', '13', 'article', '1', '1', 'sk', 'backoffice/recruitment/volne-pozicie/python-academy', '15/8/20/13', '15/8/20/13', '2015-05-29 14:57:02');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('79', '22', 'article', '1', '1', 'sk', 'backoffice/recruitment/recruitment', '15/8/22', '15/8/22', '2015-06-01 12:59:37');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('80', '23', 'article', '1', '1', 'sk', 'backoffice/recruitment/referral-fee/referral-fee', '15/8/26/23', '15/8/26/23', '2015-06-01 13:00:59');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('81', '24', 'article', '1', '1', 'sk', 'backoffice/recruitment/vitajte-v-ness/vitajte-v-ness', '15/8/27/24', '15/8/27/24', '2015-06-01 13:01:40');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('87', '25', 'page', '1', '1', 'sk', 'backoffice/recruitment/team', '15/8/25', '15/8/25', '2015-06-01 15:02:51');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('88', '25', 'article', '1', '1', 'sk', 'backoffice/recruitment/team/jaroslava-dermek', '15/8/25/25', '15/8/25/25', '2015-06-01 15:02:51');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('89', '26', 'article', '1', '1', 'sk', 'backoffice/recruitment/team/kristina-huncarova', '15/8/25/26', '15/8/25/26', '2015-06-01 15:02:52');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('90', '27', 'article', '1', '1', 'sk', 'backoffice/recruitment/team/dana-susterova', '15/8/25/27', '15/8/25/27', '2015-06-01 15:02:52');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('91', '28', 'article', '1', '1', 'sk', 'backoffice/recruitment/team/andrea-takacova', '15/8/25/28', '15/8/25/28', '2015-06-01 15:02:52');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('92', '29', 'article', '1', '1', 'sk', 'backoffice/recruitment/team/alena-stefanikova', '15/8/25/29', '15/8/25/29', '2015-06-01 15:02:52');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('93', '30', 'article', '1', '1', 'sk', 'news/chladnicky', '21/30', '21/30', '2015-06-03 10:23:45');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('94', '31', 'article', '1', '1', 'sk', 'backoffice/hr/hr', '15/5/31', '15/5/31', '2015-06-04 14:58:34');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('97', '6', 'page', '1', '1', 'sk', 'backoffice/hr/team', '15/5/6', '15/5/6', '2015-06-04 15:06:05');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('98', '32', 'article', '1', '1', 'sk', 'backoffice/hr/team/zuzana-velesova', '15/5/6/32', '15/5/6/32', '2015-06-04 15:06:06');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('99', '33', 'article', '1', '1', 'sk', 'backoffice/hr/team/branislav-targos', '15/5/6/33', '15/5/6/33', '2015-06-04 15:11:37');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('100', '34', 'article', '1', '1', 'sk', 'backoffice/hr/team/lucia-beova', '15/5/6/34', '15/5/6/34', '2015-06-04 15:13:03');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('101', '35', 'article', '1', '1', 'sk', 'backoffice/hr/team/martina-bobikova', '15/5/6/35', '15/5/6/35', '2015-06-04 15:14:21');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('103', '31', 'page', '1', '1', 'sk', 'backoffice/hr/ocenenia', '15/5/31', '15/5/31', '2015-06-04 16:03:48');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_role` smallint(4) unsigned NOT NULL,
  `join_date` timestamp NULL DEFAULT NULL,
  `last_visit` timestamp NULL DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `screen_name` varchar(50) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthdate` datetime DEFAULT NULL,
  `gender` smallint(1) DEFAULT NULL COMMENT '1: Male, 2 : Female',
  `password` varchar(255) NOT NULL,
  `email` varchar(120) NOT NULL,
  `salt` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `username` (`username`),
  KEY `id_role` (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id_user`, `id_role`, `join_date`, `last_visit`, `username`, `screen_name`, `firstname`, `lastname`, `birthdate`, `gender`, `password`, `email`, `salt`) VALUES ('1', '1', '2015-05-20 13:38:39', '2015-06-04 08:27:20', 'marek.boros@ness.com', 'Marek Boroš', 'Marek', 'Boroš', NULL, NULL, 'uxoJ4+mJ56BOiIS9DWv80bI=', 'marek.boros@ness.com', 'ce2eed574c662a0d');


