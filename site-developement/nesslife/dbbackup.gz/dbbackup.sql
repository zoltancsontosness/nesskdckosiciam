#
# TABLE STRUCTURE FOR: api_key
#

DROP TABLE IF EXISTS `api_key`;

CREATE TABLE `api_key` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(40) NOT NULL,
  `level` int(2) NOT NULL,
  `ignore_limits` tinyint(1) NOT NULL DEFAULT '0',
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `ip_addresses` text,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: api_log
#

DROP TABLE IF EXISTS `api_log`;

CREATE TABLE `api_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `method` varchar(6) NOT NULL,
  `params` text,
  `api_key` varchar(40) NOT NULL,
  `date_log` datetime DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `authorized` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: article
#

DROP TABLE IF EXISTS `article`;

CREATE TABLE `article` (
  `id_article` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `author` varchar(55) DEFAULT NULL,
  `updater` varchar(55) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_off` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logical_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `indexed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `id_category` int(11) unsigned DEFAULT NULL,
  `comment_allow` char(1) DEFAULT '0',
  `comment_autovalid` char(1) DEFAULT '0',
  `comment_expire` datetime DEFAULT NULL,
  `flag` smallint(1) DEFAULT '0',
  `has_url` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `priority` smallint(1) unsigned NOT NULL DEFAULT '5',
  PRIMARY KEY (`id_article`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('1', '404', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', NULL, '0', '0', NULL, '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('2', '401', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', NULL, '0', '0', NULL, '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('3', '403', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', NULL, '0', '0', NULL, '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('4', 'welcome', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', NULL, '0', '0', NULL, '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('5', 'oznam-cafeteria', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 15:20:14', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 08:51:58', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('6', 'dobrovonicky-de-v-oaze', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 15:22:59', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 08:54:00', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('7', 'timesheets', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 11:42:13', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 11:46:36', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('8', 'garaz-na-bicykle', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 11:48:11', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 11:48:47', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('9', 'special-referral-fee', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 12:14:53', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 12:15:16', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('10', 'front-end-javascript-developer', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 13:03:28', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-28 14:21:50', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('11', 'c-senior-developer', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 13:05:59', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-28 14:21:10', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('12', 'oracle-database-specialist', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 13:07:13', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-28 14:20:46', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('13', 'python-developer', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 13:22:39', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-28 14:22:09', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('14', 'all-staff', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-26 08:26:49', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 08:27:13', '2015-05-28 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('15', 'pivo', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-26 08:27:29', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 08:27:43', '2015-05-27 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');
INSERT INTO `article` (`id_article`, `name`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `indexed`, `id_category`, `comment_allow`, `comment_autovalid`, `comment_expire`, `flag`, `has_url`, `priority`) VALUES ('16', 'oznam-cafeteria-2', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-26 08:52:09', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 08:52:52', '0000-00-00 00:00:00', '0', NULL, '0', '0', '0000-00-00 00:00:00', '0', '1', '5');


#
# TABLE STRUCTURE FOR: article_category
#

DROP TABLE IF EXISTS `article_category`;

CREATE TABLE `article_category` (
  `id_article` int(11) unsigned NOT NULL,
  `id_category` int(11) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `article_category` (`id_article`, `id_category`) VALUES ('7', '2');
INSERT INTO `article_category` (`id_article`, `id_category`) VALUES ('8', '5');
INSERT INTO `article_category` (`id_article`, `id_category`) VALUES ('9', '4');


#
# TABLE STRUCTURE FOR: article_comment
#

DROP TABLE IF EXISTS `article_comment`;

CREATE TABLE `article_comment` (
  `id_article_comment` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_article` int(11) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `site` varchar(255) DEFAULT NULL,
  `content` text,
  `ip` varchar(40) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `admin` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'If comment comes from admin, set to 1',
  PRIMARY KEY (`id_article_comment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: article_lang
#

DROP TABLE IF EXISTS `article_lang`;

CREATE TABLE `article_lang` (
  `id_article` int(11) unsigned NOT NULL DEFAULT '0',
  `lang` varchar(8) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `content` longtext,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `online` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_article`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('1', 'sk', '404', '404', NULL, NULL, '<p>The content you asked for was not found !</p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('2', 'sk', '401', '401', 'Please login', NULL, '<p>Please login to see this content.</p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('3', 'sk', '403', '403', 'Forbidden', NULL, '<p>This content is forbidden.</p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('4', 'sk', 'welcome', 'Welcome', NULL, NULL, '<p>For more information about building a website with Ionize, you can:</p> <ul><li>Download & read <a href=\"http://www.ionizecms.com\">the Documentation</a></li><li>Visit <a href=\"http://www.ionizecms.com/forum\">the Community Forum</a></li></ul><p>Have fun !</p>', NULL, NULL, '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('5', 'sk', 'oznam-cafeteria', 'Oznam: Cafeteria', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('6', 'sk', 'dobrovonicky-de-v-oaze', 'Dobrovoľnícky deň v Oáze', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('7', 'sk', 'timesheets', 'TIMESHEETS', '', '', '<p>Vyplň a releasni si svoj TMSH za obdobie 1.5.2015- 15.5.2015 /vrátane/ najneskôr 15.5.2015 do 10:00 hod</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('8', 'sk', 'garaz-na-bicykle', 'Garáž na bicykle', '', '', '<p>Zajtra t.j. 22.5.2015 prebehne vymena zamku na garazi kde sa odkladaju bicykle. Preto Vas poprosim, aby ste bicykle nedavali do garaze, je mozne si ich vziat do priestorov NESS KDC.</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('9', 'sk', 'special-referral-fee', 'SPECIAL REFERRAL FEE', '', '', '<p>Pošli nám tip na skúsených developerov a získaj atraktívnu odmenu - LEN DO KONCA MÁJA!</p>', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('10', 'sk', 'front-end-javascript-developer', 'Front End Javascript Developer', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('11', 'sk', 'c-senior-developer', 'c# Senior Developer', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('12', 'sk', 'oracle-database-specialist', 'Oracle Database Specialist', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('13', 'sk', 'python-developer', 'Python Junior Developer', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('14', 'sk', 'all-staff', 'All staff', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('15', 'sk', 'pivo', 'Pivo', '', '', '', '', '', '1');
INSERT INTO `article_lang` (`id_article`, `lang`, `url`, `title`, `subtitle`, `meta_title`, `content`, `meta_keywords`, `meta_description`, `online`) VALUES ('16', 'sk', 'oznam-cafeteria-2', 'Oznam: Cafeteria 2', '', '', '', '', '', '1');


#
# TABLE STRUCTURE FOR: article_media
#

DROP TABLE IF EXISTS `article_media`;

CREATE TABLE `article_media` (
  `id_article` int(11) unsigned NOT NULL DEFAULT '0',
  `id_media` int(11) unsigned NOT NULL DEFAULT '0',
  `online` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) unsigned DEFAULT '9999',
  `url` varchar(255) DEFAULT NULL,
  `lang_display` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id_article`,`id_media`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('5', '7', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('6', '9', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('10', '13', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('11', '11', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('12', '10', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('13', '12', '1', '1', NULL, NULL);
INSERT INTO `article_media` (`id_article`, `id_media`, `online`, `ordering`, `url`, `lang_display`) VALUES ('16', '8', '1', '1', NULL, NULL);


#
# TABLE STRUCTURE FOR: article_tag
#

DROP TABLE IF EXISTS `article_tag`;

CREATE TABLE `article_tag` (
  `id_article` int(11) unsigned NOT NULL,
  `id_tag` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id_article`,`id_tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: article_type
#

DROP TABLE IF EXISTS `article_type`;

CREATE TABLE `article_type` (
  `id_type` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `ordering` int(11) DEFAULT '0',
  `description` text,
  `type_flag` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: captcha
#

DROP TABLE IF EXISTS `captcha`;

CREATE TABLE `captcha` (
  `id_captcha` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL DEFAULT '',
  `answer` varchar(255) NOT NULL DEFAULT '',
  `lang` varchar(8) NOT NULL DEFAULT '',
  `hash` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_captcha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id_category` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`id_category`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `category` (`id_category`, `name`, `ordering`) VALUES ('1', 'hr', '0');
INSERT INTO `category` (`id_category`, `name`, `ordering`) VALUES ('2', 'reception', '0');
INSERT INTO `category` (`id_category`, `name`, `ordering`) VALUES ('3', 'ito', '0');
INSERT INTO `category` (`id_category`, `name`, `ordering`) VALUES ('4', 'recruitment', '0');
INSERT INTO `category` (`id_category`, `name`, `ordering`) VALUES ('5', 'operations', '0');


#
# TABLE STRUCTURE FOR: category_lang
#

DROP TABLE IF EXISTS `category_lang`;

CREATE TABLE `category_lang` (
  `id_category` int(11) unsigned NOT NULL DEFAULT '0',
  `lang` varchar(8) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  PRIMARY KEY (`id_category`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `category_lang` (`id_category`, `lang`, `title`, `subtitle`, `description`) VALUES ('1', 'sk', 'HR', '', '');
INSERT INTO `category_lang` (`id_category`, `lang`, `title`, `subtitle`, `description`) VALUES ('2', 'sk', 'Reception', '', '');
INSERT INTO `category_lang` (`id_category`, `lang`, `title`, `subtitle`, `description`) VALUES ('3', 'sk', 'ITO', '', '');
INSERT INTO `category_lang` (`id_category`, `lang`, `title`, `subtitle`, `description`) VALUES ('4', 'sk', 'Recruitment', '', '');
INSERT INTO `category_lang` (`id_category`, `lang`, `title`, `subtitle`, `description`) VALUES ('5', 'sk', 'Operations', '', '');


#
# TABLE STRUCTURE FOR: element
#

DROP TABLE IF EXISTS `element`;

CREATE TABLE `element` (
  `id_element` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_element_definition` int(11) unsigned NOT NULL,
  `parent` varchar(50) NOT NULL,
  `id_parent` int(11) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_element`),
  KEY `idx_element_id_element_definition` (`id_element_definition`),
  KEY `idx_element_id_parent` (`id_parent`),
  KEY `idx_element_parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: element_definition
#

DROP TABLE IF EXISTS `element_definition`;

CREATE TABLE `element_definition` (
  `id_element_definition` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text,
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_element_definition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: element_definition_lang
#

DROP TABLE IF EXISTS `element_definition_lang`;

CREATE TABLE `element_definition_lang` (
  `id_element_definition` int(11) unsigned NOT NULL,
  `lang` varchar(8) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_element_definition`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: event_log
#

DROP TABLE IF EXISTS `event_log`;

CREATE TABLE `event_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(50) DEFAULT NULL,
  `message` text,
  `id_user` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: extend_field
#

DROP TABLE IF EXISTS `extend_field`;

CREATE TABLE `extend_field` (
  `id_extend_field` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` int(3) unsigned NOT NULL,
  `description` varchar(255) DEFAULT '',
  `parent` varchar(50) NOT NULL,
  `id_parent` int(11) unsigned DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `translated` char(1) DEFAULT '0',
  `value` text,
  `default_value` varchar(255) DEFAULT NULL,
  `global` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `main` smallint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_extend_field`),
  KEY `idx_extend_field_parent` (`parent`),
  KEY `idx_extend_field_id_parent` (`id_parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: extend_field_lang
#

DROP TABLE IF EXISTS `extend_field_lang`;

CREATE TABLE `extend_field_lang` (
  `id_extend_field` int(11) unsigned NOT NULL,
  `lang` varchar(8) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_extend_field`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: extend_field_type
#

DROP TABLE IF EXISTS `extend_field_type`;

CREATE TABLE `extend_field_type` (
  `id_extend_field_type` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) NOT NULL DEFAULT '',
  `default_values` smallint(1) NOT NULL DEFAULT '0',
  `values` smallint(1) NOT NULL DEFAULT '0',
  `translated` smallint(1) NOT NULL DEFAULT '0',
  `active` smallint(6) NOT NULL DEFAULT '1',
  `display` smallint(6) NOT NULL DEFAULT '1',
  `validate` varchar(50) DEFAULT NULL,
  `html_element` varchar(20) NOT NULL DEFAULT 'input',
  `html_element_type` varchar(20) NOT NULL DEFAULT 'text',
  `html_element_class` varchar(100) DEFAULT NULL,
  `html_element_pattern` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_extend_field_type`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8;

INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('1', 'Input', '1', '0', '1', '1', '1', NULL, 'input', 'text', 'w95p inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('2', 'Textarea', '1', '0', '1', '1', '1', NULL, 'textarea', 'textarea', 'w95p autogrow inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('3', 'Textarea + Editor', '1', '0', '1', '1', '1', NULL, 'textarea', 'editor', 'w95p smallTinyTextarea inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('4', 'Checkbox', '1', '1', '0', '1', '1', NULL, 'input', 'checkbox', 'checkbox', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('5', 'Radio', '1', '1', '0', '1', '1', NULL, 'input', 'radio', 'radio', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('6', 'Select', '1', '1', '0', '1', '1', NULL, 'input', 'select', 'select inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('7', 'Date Time', '0', '0', '0', '1', '1', NULL, 'input', 'date', 'date w120 inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('8', 'Medias', '0', '0', '1', '1', '1', NULL, 'div', 'media', NULL, NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('100', 'Number', '1', '0', '0', '1', '1', 'numeric', 'input', 'number', 'w120 inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('110', 'Email', '0', '0', '0', '1', '1', 'email', 'input', 'email', 'w95p inputtext', NULL);
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('120', 'Phone', '0', '0', '0', '1', '1', 'digits', 'input', 'tel', 'w140 inputtext', '^((\\+\\d{1,3}(-| )?\\(?\\d\\)?(-| )?\\d{1,5})|(\\(?\\d{2,6}\\)?))(-| )?(\\d{3,4})(-| )?(\\d{4})(( x| ext)\\d{1,5}){0,1}$');
INSERT INTO `extend_field_type` (`id_extend_field_type`, `type_name`, `default_values`, `values`, `translated`, `active`, `display`, `validate`, `html_element`, `html_element_type`, `html_element_class`, `html_element_pattern`) VALUES ('130', 'Internal Link', '0', '0', '1', '1', '1', NULL, 'div', 'link', 'droppable', NULL);


#
# TABLE STRUCTURE FOR: extend_fields
#

DROP TABLE IF EXISTS `extend_fields`;

CREATE TABLE `extend_fields` (
  `id_extend_fields` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_extend_field` int(11) unsigned NOT NULL,
  `parent` varchar(50) NOT NULL DEFAULT '',
  `id_parent` int(11) unsigned NOT NULL,
  `lang` varchar(8) NOT NULL DEFAULT '',
  `content` text,
  `ordering` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_extend_fields`),
  KEY `idx_extend_fields_id_parent` (`id_parent`),
  KEY `idx_extend_fields_lang` (`lang`),
  KEY `idx_extend_fields_id_extend_field` (`id_extend_field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ion_sessions
#

DROP TABLE IF EXISTS `ion_sessions`;

CREATE TABLE `ion_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) DEFAULT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item
#

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `id_item` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_item_definition` int(10) unsigned NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `description` text,
  `ordering` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item instances';

#
# TABLE STRUCTURE FOR: item_definition
#

DROP TABLE IF EXISTS `item_definition`;

CREATE TABLE `item_definition` (
  `id_item_definition` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id_item_definition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Items definition table';

#
# TABLE STRUCTURE FOR: item_definition_lang
#

DROP TABLE IF EXISTS `item_definition_lang`;

CREATE TABLE `item_definition_lang` (
  `id_item_definition` int(11) unsigned NOT NULL,
  `lang` varchar(8) NOT NULL DEFAULT '',
  `title_definition` varchar(50) DEFAULT NULL,
  `title_item` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_item_definition`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item_lang
#

DROP TABLE IF EXISTS `item_lang`;

CREATE TABLE `item_lang` (
  `id_item` int(11) unsigned NOT NULL,
  `lang` varchar(8) NOT NULL DEFAULT '',
  `title` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_item`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS `items`;

CREATE TABLE `items` (
  `id_item` int(11) unsigned NOT NULL,
  `parent` varchar(50) NOT NULL DEFAULT '',
  `id_parent` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_item`,`parent`,`id_parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: lang
#

DROP TABLE IF EXISTS `lang`;

CREATE TABLE `lang` (
  `lang` varchar(8) NOT NULL DEFAULT '',
  `name` varchar(40) DEFAULT NULL,
  `online` char(1) DEFAULT '0',
  `def` char(1) DEFAULT '0',
  `ordering` int(11) DEFAULT NULL,
  `direction` smallint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `lang` (`lang`, `name`, `online`, `def`, `ordering`, `direction`) VALUES ('sk', 'slovak', '1', '1', '1', '1');


#
# TABLE STRUCTURE FOR: login_tracker
#

DROP TABLE IF EXISTS `login_tracker`;

CREATE TABLE `login_tracker` (
  `ip_address` varchar(32) NOT NULL,
  `first_time` int(11) unsigned NOT NULL,
  `failures` tinyint(2) unsigned DEFAULT NULL,
  PRIMARY KEY (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: media
#

DROP TABLE IF EXISTS `media`;

CREATE TABLE `media` (
  `id_media` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL DEFAULT '',
  `file_name` varchar(255) NOT NULL DEFAULT '' COMMENT 'file_name',
  `path` varchar(500) NOT NULL COMMENT 'Complete path to the medium, including media file name, excluding host name',
  `base_path` varchar(500) NOT NULL COMMENT 'medium folder base path, excluding host name',
  `copyright` varchar(128) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Medium date',
  `link` varchar(255) DEFAULT NULL COMMENT 'Link to a resource, attached to this medium',
  `square_crop` enum('tl','m','br') NOT NULL DEFAULT 'm',
  PRIMARY KEY (`id_media`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('1', 'picture', 'oznam.jpg', 'files/slideshow/oznam.jpg', 'files/slideshow/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('2', 'picture', 'oaza.jpg', 'files/slideshow/oaza.jpg', 'files/slideshow/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('3', 'picture', 'solar.png', 'files/projects/solar.png', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('4', 'picture', 'vix.png', 'files/projects/vix.png', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('5', 'picture', 'opera.png', 'files/projects/opera.png', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('6', 'picture', 'tribal.png', 'files/projects/tribal.png', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('7', 'picture', 'oznam2.jpg', 'files/slideshow/oznam2.jpg', 'files/slideshow/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('8', 'picture', 'oznam3.jpg', 'files/slideshow/oznam3.jpg', 'files/slideshow/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('9', 'picture', 'oaza2.jpg', 'files/slideshow/oaza2.jpg', 'files/slideshow/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('10', 'picture', 'Opera.jpg', 'files/projects/Opera.jpg', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('11', 'picture', 'vix.jpg', 'files/projects/vix.jpg', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('12', 'picture', 'solar.jpg', 'files/projects/solar.jpg', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');
INSERT INTO `media` (`id_media`, `type`, `file_name`, `path`, `base_path`, `copyright`, `provider`, `date`, `link`, `square_crop`) VALUES ('13', 'picture', 'perform.jpg', 'files/projects/perform.jpg', 'files/projects/', NULL, '', '0000-00-00 00:00:00', NULL, 'm');


#
# TABLE STRUCTURE FOR: media_lang
#

DROP TABLE IF EXISTS `media_lang`;

CREATE TABLE `media_lang` (
  `lang` varchar(8) NOT NULL DEFAULT '',
  `id_media` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `alt` varchar(500) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`id_media`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: menu
#

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `ordering` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_menu`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `menu` (`id_menu`, `name`, `title`, `ordering`) VALUES ('1', 'main', 'Main menu', NULL);
INSERT INTO `menu` (`id_menu`, `name`, `title`, `ordering`) VALUES ('2', 'system', 'System menu', NULL);


#
# TABLE STRUCTURE FOR: module
#

DROP TABLE IF EXISTS `module`;

CREATE TABLE `module` (
  `id_module` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `with_admin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `version` varchar(10) NOT NULL DEFAULT '',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `info` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id_module`),
  KEY `i_module_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: module_setting
#

DROP TABLE IF EXISTS `module_setting`;

CREATE TABLE `module_setting` (
  `id_module_setting` int(11) NOT NULL AUTO_INCREMENT,
  `id_module` int(11) NOT NULL,
  `name` varchar(50) NOT NULL COMMENT 'Setting name',
  `content` varchar(255) NOT NULL COMMENT 'Setting content',
  `lang` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id_module_setting`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: note
#

DROP TABLE IF EXISTS `note`;

CREATE TABLE `note` (
  `id_note` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(10) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id_note`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: notification
#

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `id_notification` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date_creation` date DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `category` varchar(25) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` text,
  `read` smallint(1) DEFAULT '0',
  PRIMARY KEY (`id_notification`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `notification` (`id_notification`, `date_creation`, `code`, `category`, `title`, `content`, `read`) VALUES ('1', '2015-05-28', 'sitemap_refresh', 'System', 'Sitemap refresh', 'Sitemap needs to be refreshed.<br/> Go to <b>Tools > System Diagnosis > Tools</b> and click on <b>\"Refresh Sitemap\"</b>.', '0');


#
# TABLE STRUCTURE FOR: page
#

DROP TABLE IF EXISTS `page`;

CREATE TABLE `page` (
  `id_page` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_parent` int(11) unsigned NOT NULL DEFAULT '0',
  `id_menu` int(11) unsigned NOT NULL DEFAULT '0',
  `id_type` smallint(2) NOT NULL DEFAULT '0',
  `id_subnav` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `ordering` int(11) unsigned DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `online` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` tinyint(1) NOT NULL DEFAULT '0',
  `author` varchar(55) DEFAULT NULL,
  `updater` varchar(55) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_off` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logical_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `appears` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `has_url` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `view` varchar(50) DEFAULT NULL COMMENT 'Page view',
  `view_single` varchar(50) DEFAULT NULL COMMENT 'Single Article Page view',
  `article_list_view` varchar(50) DEFAULT NULL COMMENT 'Article list view for each article linked to this page',
  `article_view` varchar(50) DEFAULT NULL COMMENT 'Article detail view for each article linked to this page',
  `article_order` varchar(50) NOT NULL DEFAULT 'ordering' COMMENT 'Article order in this page. Can be "ordering", "date"',
  `article_order_direction` varchar(50) NOT NULL DEFAULT 'ASC',
  `link` varchar(255) DEFAULT '' COMMENT 'Link to internal / external resource',
  `link_type` varchar(25) DEFAULT NULL COMMENT '''page'', ''article'' or NULL',
  `link_id` varchar(20) NOT NULL DEFAULT '',
  `pagination` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Pagination use ?',
  `priority` int(1) unsigned NOT NULL DEFAULT '5' COMMENT 'Page priority',
  `used_by_module` tinyint(1) unsigned DEFAULT NULL,
  `deny_code` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id_page`),
  KEY `idx_page_id_parent` (`id_parent`),
  KEY `idx_page_level` (`level`),
  KEY `idx_page_menu` (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('1', '0', '2', '0', '0', '404', '0', '0', '1', '0', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', NULL, NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '0', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('2', '0', '2', '0', '0', '401', '0', '0', '1', '0', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', NULL, NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '0', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('3', '0', '2', '0', '0', '403', '0', '0', '1', '0', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', NULL, NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '0', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('4', '0', '1', '0', '0', 'home', '1', '0', '1', '1', NULL, 'marek.boros@ness.com', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-20 15:37:47', '0000-00-00 00:00:00', '1', '1', 'page_home', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('5', '15', '1', '0', '0', 'hr', '3', '1', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 14:47:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 10:34:02', '0000-00-00 00:00:00', '1', '1', '', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('6', '5', '1', '0', '0', 'nas-tim', '2', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 14:51:42', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('7', '0', '2', '0', '0', 'slideshow', '1', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 15:18:41', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('8', '15', '1', '0', '0', 'recruitment', '4', '1', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 15:36:03', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 10:34:23', '0000-00-00 00:00:00', '1', '1', '', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('9', '15', '1', '0', '0', 'operations', '5', '1', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 15:36:16', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-22 10:35:24', '0000-00-00 00:00:00', '1', '1', '', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('10', '0', '1', '0', '0', 'forum', '4', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 15:36:33', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('11', '0', '1', '0', '0', 'aj-ty', '5', '0', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-20 15:36:49', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-26 10:54:51', '0000-00-00 00:00:00', '1', '1', '', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('12', '0', '1', '0', '0', 'dokumenty', '6', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 15:36:59', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('13', '0', '1', '0', '0', 'galerie', '7', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 15:37:08', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('14', '0', '1', '0', '0', 'kontakt', '8', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-20 15:37:19', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('15', '0', '1', '0', '0', 'backoffice', '3', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-22 10:33:36', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('16', '15', '1', '0', '0', 'finance', '11', '1', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-22 10:36:05', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('17', '9', '1', '0', '0', 'reception', '2', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-22 11:24:09', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('18', '9', '1', '0', '0', 'travel', '3', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-22 11:24:28', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('19', '9', '1', '0', '0', 'ito', '6', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-22 11:24:40', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('20', '8', '1', '0', '0', 'vone-pozicie', '2', '2', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 11:31:38', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-28 14:28:10', '0000-00-00 00:00:00', '1', '1', 'page_rcr_positions', '', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('21', '0', '1', '0', '0', 'news', '2', '0', '1', '0', 'marek.boros@ness.com', 'marek.boros@ness.com', '2015-05-22 11:34:11', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-28 15:19:47', '0000-00-00 00:00:00', '1', '1', 'page_news', 'page_news_single_article', NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', '0', '404');
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('22', '9', '1', '0', '0', 'team', '1', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:45:50', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('23', '9', '1', '0', '0', 'purchasing', '4', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:46:23', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('24', '9', '1', '0', '0', 'logistics', '5', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:47:05', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('25', '8', '1', '0', '0', 'team-1', '1', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:49:48', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('26', '8', '1', '0', '0', 'referral-fee', '12', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:50:20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('27', '8', '1', '0', '0', 'vitajte-v-ness', '13', '2', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-25 14:50:42', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);
INSERT INTO `page` (`id_page`, `id_parent`, `id_menu`, `id_type`, `id_subnav`, `name`, `ordering`, `level`, `online`, `home`, `author`, `updater`, `created`, `publish_on`, `publish_off`, `updated`, `logical_date`, `appears`, `has_url`, `view`, `view_single`, `article_list_view`, `article_view`, `article_order`, `article_order_direction`, `link`, `link_type`, `link_id`, `pagination`, `priority`, `used_by_module`, `deny_code`) VALUES ('28', '0', '2', '0', '0', 'events', '2', '0', '1', '0', 'marek.boros@ness.com', NULL, '2015-05-26 08:24:22', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '1', '0', NULL, NULL, NULL, 'ordering', 'ASC', '', NULL, '', '0', '5', NULL, NULL);


#
# TABLE STRUCTURE FOR: page_article
#

DROP TABLE IF EXISTS `page_article`;

CREATE TABLE `page_article` (
  `id_page` int(11) unsigned NOT NULL,
  `id_article` int(11) unsigned NOT NULL,
  `online` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `view` varchar(50) DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `id_type` int(11) unsigned DEFAULT NULL,
  `link_type` varchar(25) NOT NULL DEFAULT '',
  `link_id` varchar(20) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `main_parent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_page`,`id_article`),
  KEY `idx_page_article_id_type` (`id_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('1', '1', '1', NULL, '0', NULL, '', '', '', '0');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('2', '2', '1', NULL, '0', NULL, '', '', '', '0');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('3', '3', '1', NULL, '0', NULL, '', '', '', '0');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('4', '4', '1', NULL, '0', NULL, '', '', '', '0');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('7', '5', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('7', '6', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('7', '16', '1', NULL, '3', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('20', '10', '1', NULL, '3', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('20', '11', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('20', '12', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('20', '13', '1', NULL, '4', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('21', '7', '1', NULL, '3', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('21', '8', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('21', '9', '1', NULL, '1', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('28', '14', '1', NULL, '2', NULL, '', '', '', '1');
INSERT INTO `page_article` (`id_page`, `id_article`, `online`, `view`, `ordering`, `id_type`, `link_type`, `link_id`, `link`, `main_parent`) VALUES ('28', '15', '1', NULL, '1', NULL, '', '', '', '1');


#
# TABLE STRUCTURE FOR: page_lang
#

DROP TABLE IF EXISTS `page_lang`;

CREATE TABLE `page_lang` (
  `lang` varchar(8) NOT NULL DEFAULT '',
  `id_page` int(11) unsigned NOT NULL DEFAULT '0',
  `url` varchar(100) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `subnav_title` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `online` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_page`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '1', '404', '', '404', 'Can\'t find requested page.', '', '', NULL, NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '2', '401', '', '401', 'Login needed', '', '', NULL, NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '3', '403', '', '403', 'Forbidden', '', '', NULL, NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '4', 'home', '', 'Home', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '5', 'hr', '', 'HR', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '6', 'nas-tim', '', 'Náš tím', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '7', 'slideshow', '', 'SlideShow', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '8', 'recruitment', '', 'Recruitment', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '9', 'operations', '', 'Operations', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '10', 'forum', '', 'Fórum', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '11', 'aj-ty', '', 'A:J TY', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '12', 'dokumenty', '', 'Dokumenty', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '13', 'galerie', '', 'Galérie', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '14', 'kontakt', '', 'Kontakt', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '15', 'backoffice', '', 'BackOffice', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '16', 'finance', '', 'Finance', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '17', 'reception', '', 'Reception', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '18', 'travel', '', 'Travel', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '19', 'ito', '', 'ITO', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '20', 'volne-pozicie', '', 'Pozície', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '21', 'news', '', 'News', '', '', '', '', '', '', '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '22', 'team', '', 'Team', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '23', 'purchasing', '', 'Purchasing', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '24', 'logistics', '', 'Logistics', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '25', 'team', '', 'Team', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '26', 'referral-fee', '', 'Referral fee', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '27', 'vitajte-v-ness', '', 'Vitajte v Ness', '', '', '', '', NULL, NULL, '1');
INSERT INTO `page_lang` (`lang`, `id_page`, `url`, `link`, `title`, `subtitle`, `nav_title`, `subnav_title`, `meta_title`, `meta_description`, `meta_keywords`, `online`) VALUES ('sk', '28', 'events', '', 'Events', '', '', '', '', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: page_media
#

DROP TABLE IF EXISTS `page_media`;

CREATE TABLE `page_media` (
  `id_page` int(11) unsigned NOT NULL DEFAULT '0',
  `id_media` int(11) unsigned NOT NULL DEFAULT '0',
  `online` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) unsigned DEFAULT '9999',
  `lang_display` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id_page`,`id_media`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: resource
#

DROP TABLE IF EXISTS `resource`;

CREATE TABLE `resource` (
  `id_resource` int(11) NOT NULL AUTO_INCREMENT,
  `id_parent` int(11) unsigned DEFAULT NULL,
  `resource` varchar(255) NOT NULL DEFAULT '',
  `actions` varchar(500) DEFAULT '',
  `title` varchar(255) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  PRIMARY KEY (`id_resource`),
  UNIQUE KEY `resource_key` (`resource`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8;

INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('1', NULL, 'admin', '', 'Backend login', 'Connect to ionize backend');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('10', NULL, 'admin/menu', 'create,edit,delete', 'Menu', 'Menus');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('11', '10', 'admin/menu/permissions/backend', '', 'Permissions', 'Menu > Backend Permissions');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('20', NULL, 'admin/translations', '', 'Translations', 'Translations');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('30', NULL, 'admin/filemanager', 'upload,rename,delete,move', 'Filemanager', 'FileManager');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('35', NULL, 'admin/medialist', '', 'MediaList', 'MediaList');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('40', NULL, 'admin/page', 'create,edit,delete', 'Page', 'Page');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('41', '40', 'admin/page/article', 'add', 'Article', 'Page > Article');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('42', '40', 'admin/page/element', 'add', 'Content Element', 'Page > Content Element');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('50', '40', 'admin/page/media', 'link,unlink,edit', 'Media', 'Page > Media');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('60', '40', 'admin/page/permissions', '', 'Permission', 'Page > Permission');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('61', '60', 'admin/page/permissions/backend', '', 'Backend', 'Page > Permission > Backend');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('62', '60', 'admin/page/permissions/frontend', '', 'Frontend', 'Page > Permission > Frontend');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('70', NULL, 'admin/article', 'create,edit,delete,move,copy,duplicate', 'Article', 'Article');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('80', '70', 'admin/article/media', 'link,unlink,edit', 'Media', 'Article > Media');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('85', '70', 'admin/article/element', 'add', 'Content Element', 'Article > Content Element');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('86', '70', 'admin/article/category', '', 'Manage categories', 'Article > Categories');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('90', '70', 'admin/article/permissions', '', 'Permission', 'Article > Permission');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('91', '90', 'admin/article/permissions/backend', '', 'Backend', 'Article > Permission > Backend');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('92', '90', 'admin/article/permissions/frontend', '', 'Frontend', 'Article > Permission > Frontend');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('93', '70', 'admin/article/tag', '', 'Manage tags', 'Article > Tags');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('100', NULL, 'admin/tree', '', 'Tree', '');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('101', '100', 'admin/tree/menu', 'add_page,edit', 'Menus', '');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('102', '100', 'admin/tree/page', 'status,add_page,add_article,order', 'Pages', '');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('103', '100', 'admin/tree/article', 'unlink,status,move,copy,order', 'Articles', '');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('120', NULL, 'admin/article/type', 'create,edit,delete', 'Article Type', 'Article types');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('150', NULL, 'admin/modules', 'install', 'Modules', 'Modules');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('151', '150', 'admin/modules/permissions', '', 'Set Permissions', 'Modules > Permissions');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('180', NULL, 'admin/element', 'create,edit,delete', 'Content Element', 'Content Elements');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('181', '180', 'admin/element/media', 'link,unlink,edit', 'Media', 'Content Elements > Media');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('210', NULL, 'admin/extend', 'create,edit,delete', 'Extend Fields', 'Extend Fields');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('220', NULL, 'admin/item', 'create,edit,delete,add', 'Static Items', 'Static Items');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('221', '220', 'admin/item/definition', 'edit', 'Definition', 'Static Items > Definition');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('222', '220', 'admin/item/media', 'link,unlink,edit', 'Media', 'Static Items > Media');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('240', NULL, 'admin/tools', '', 'Tools', 'Tools');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('241', '240', 'admin/tools/google_analytics', '', 'Google Analytics', 'Tools > Google Analytics');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('250', '240', 'admin/tools/system', '', 'System Diagnosis', 'Tools > System');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('251', '250', 'admin/tools/system/information', '', 'Information', 'Tools > System > Information');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('252', '250', 'admin/tools/system/repair', '', 'Repair tools', 'Tools > System > Repair');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('253', '250', 'admin/tools/system/report', '', 'Reports', 'Tools > System > Reports');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('270', NULL, 'admin/settings', '', 'Settings', 'Settings');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('271', '270', 'admin/settings/ionize', '', 'Ionize UI', 'Settings > UI Settings');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('272', '270', 'admin/settings/languages', '', 'Languages Management', 'Settings > Languages');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('273', '270', 'admin/settings/themes', 'edit', 'Themes', 'Settings > Themes');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('274', '270', 'admin/settings/website', '', 'Website settings', 'Settings > Website');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('275', '270', 'admin/settings/technical', '', 'Technical settings', 'Settings > Technical');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('300', NULL, 'admin/users_roles', '', 'Users / Roles', 'Users / Roles');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('301', '300', 'admin/user', 'create,edit,delete', 'Users', 'Users');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('302', '300', 'admin/role', 'create,edit,delete', 'Roles', 'Roles');
INSERT INTO `resource` (`id_resource`, `id_parent`, `resource`, `actions`, `title`, `description`) VALUES ('303', '302', 'admin/role/permissions', '', 'Set Permissions', 'See Role\'s permissions');


#
# TABLE STRUCTURE FOR: role
#

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `id_role` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `role_level` int(11) DEFAULT NULL,
  `role_code` varchar(25) NOT NULL,
  `role_name` varchar(100) NOT NULL,
  `role_description` tinytext,
  PRIMARY KEY (`id_role`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('1', '10000', 'super-admin', 'Super Admin', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('2', '5000', 'admin', 'Admin', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('3', '1000', 'editor', 'Editor', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('4', '100', 'user', 'User', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('5', '50', 'pending', 'Pending', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('6', '10', 'guest', 'Guest', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('7', '-10', 'banned', 'Banned', '');
INSERT INTO `role` (`id_role`, `role_level`, `role_code`, `role_name`, `role_description`) VALUES ('8', '-100', 'deactivated', 'Deactivated', '');


#
# TABLE STRUCTURE FOR: rule
#

DROP TABLE IF EXISTS `rule`;

CREATE TABLE `rule` (
  `id_role` int(11) NOT NULL,
  `resource` varchar(100) NOT NULL DEFAULT '',
  `actions` varchar(100) NOT NULL DEFAULT '',
  `permission` smallint(1) DEFAULT NULL,
  `id_element` int(11) unsigned DEFAULT NULL,
  `id_user` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_role`,`resource`,`actions`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('1', 'all', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article', 'create,edit,delete,move,copy,duplicate', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/category', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/element', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/permissions/backend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/permissions/frontend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/tag', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/article/type', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/element', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/element/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/extend', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/filemanager', 'upload,rename,delete,move', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/item', 'create,edit,delete,add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/item/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/medialist', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/menu', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/modules', 'install', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/modules/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/article', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/element', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/permissions/backend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/page/permissions/frontend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/role', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/role/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/settings', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/settings/ionize', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/settings/languages', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/settings/website', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools/google_analytics', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools/system', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools/system/information', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools/system/repair', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tools/system/report', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/translations', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tree', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tree/article', 'unlink,status,move,copy,order', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tree/menu', 'add_page,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/tree/page', 'status,add_page,add_article,order', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/user', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('2', 'admin/users_roles', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article', 'create,edit,delete,move,copy,duplicate', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/category', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/element', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/permissions/backend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/permissions/frontend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/article/tag', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/element/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/filemanager', 'upload,rename,delete,move', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/item', 'create,edit,delete,add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/item/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/medialist', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/menu', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/modules', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/article', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/element', 'add', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/media', 'link,unlink,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/permissions', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/permissions/backend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/page/permissions/frontend', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/settings', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/settings/ionize', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/settings/languages', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/settings/website', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tools', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tools/google_analytics', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tools/system', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tools/system/information', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tools/system/report', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/translations', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tree', '', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tree/article', 'unlink,status,move,copy,order', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tree/menu', 'add_page,edit', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/tree/page', 'status,add_page,add_article,order', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/user', 'create,edit,delete', '1', NULL, '0');
INSERT INTO `rule` (`id_role`, `resource`, `actions`, `permission`, `id_element`, `id_user`) VALUES ('3', 'admin/users_roles', '', '1', NULL, '0');


#
# TABLE STRUCTURE FOR: setting
#

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `id_setting` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `lang` varchar(8) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_setting`),
  UNIQUE KEY `idx_unq_setting` (`name`,`lang`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('1', 'ionize_version', '1.0.7', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('2', 'site_email', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('3', 'files_path', 'files', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('4', 'theme', 'nesslife', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('5', 'theme_admin', 'admin', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('6', 'google_analytics', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('7', 'filemanager', 'mootools-filemanager', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('8', 'show_help_tips', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('9', 'display_connected_label', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('10', 'display_dashboard_shortcuts', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('11', 'display_dashboard_modules', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('12', 'display_dashboard_users', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('13', 'display_dashboard_content', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('14', 'display_front_offline_content', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('15', 'display_dashboard_quick_settings', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('16', 'texteditor', 'tinymce', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('17', 'media_thumb_size', '120', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('18', 'tinybuttons1', 'pdw_toggle,|,bold,italic,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,formatselect,|,bullist,numlist,|,link,unlink,image,|,spellchecker', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('19', 'tinybuttons2', 'fullscreen, undo,redo,|,pastetext,selectall,removeformat,|,media,charmap,hr,blockquote,|,template,|,codemirror', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('20', 'tinybuttons3', 'tablecontrols', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('21', 'smalltinybuttons1', 'bold,italic,|,bullist,numlist,|,link,unlink,image,|,nonbreaking', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('22', 'smalltinybuttons2', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('23', 'smalltinybuttons3', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('24', 'displayed_admin_languages', 'en', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('25', 'date_format', '%Y.%m.%d', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('26', 'force_lang_urls', '0', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('27', 'tinyblockformats', 'p,h2,h3,h4,h5,pre,div', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('28', 'article_allowed_tags', 'h2,h3,h4,h5,h6,em,img,iframe,table,object,thead,tbody,tfoot,tr,th,td,param,embed,map,p,a,ul,ol,li,br,b,strong', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('29', 'filemanager_file_types', 'gif,jpe,jpeg,jpg,png,flv,mpeg,mpg,mp3,pdf', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('30', 'default_admin_lang', 'en', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('31', 'upload_autostart', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('32', 'resize_on_upload', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('33', 'picture_max_width', '1200', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('34', 'picture_max_height', '1200', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('35', 'upload_mode', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('36', 'no_source_picture', 'default.png', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('37', 'enable_backend_tracker', '0', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('38', 'backend_ui_style', 'original', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('39', 'notification', '1', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('40', 'notification_date', '', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('41', 'site_title', 'My website', 'sk');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('42', 'last_notification_refresh', '2015-05-28 13:40:10', '');
INSERT INTO `setting` (`id_setting`, `name`, `content`, `lang`) VALUES ('43', 'last_version', '1.0.7', '');


#
# TABLE STRUCTURE FOR: tag
#

DROP TABLE IF EXISTS `tag`;

CREATE TABLE `tag` (
  `id_tag` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tracker
#

DROP TABLE IF EXISTS `tracker`;

CREATE TABLE `tracker` (
  `id_user` int(11) unsigned NOT NULL,
  `ip_address` varchar(32) DEFAULT NULL,
  `element` varchar(50) DEFAULT NULL,
  `id_element` int(11) DEFAULT NULL,
  `last_time` datetime DEFAULT NULL,
  `elements` varchar(3000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: type
#

DROP TABLE IF EXISTS `type`;

CREATE TABLE `type` (
  `id_type` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `parent` char(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(3000) DEFAULT NULL,
  `ordering` smallint(6) NOT NULL,
  `view` varchar(50) DEFAULT NULL COMMENT 'view',
  `flag` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ui_element
#

DROP TABLE IF EXISTS `ui_element`;

CREATE TABLE `ui_element` (
  `id_ui_element` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_company` int(11) unsigned DEFAULT NULL,
  `type` enum('tab','table','list') DEFAULT NULL,
  `panel` varchar(25) DEFAULT NULL COMMENT 'UI context',
  `title` varchar(50) DEFAULT NULL,
  `ordering` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_ui_element`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ui_element_lk_extend
#

DROP TABLE IF EXISTS `ui_element_lk_extend`;

CREATE TABLE `ui_element_lk_extend` (
  `id_ui_element` int(11) unsigned NOT NULL,
  `id_extend` int(11) NOT NULL DEFAULT '0',
  `ordering` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_ui_element`,`id_extend`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: url
#

DROP TABLE IF EXISTS `url`;

CREATE TABLE `url` (
  `id_url` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_entity` int(11) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `canonical` smallint(1) NOT NULL DEFAULT '0',
  `active` smallint(1) NOT NULL DEFAULT '0',
  `lang` varchar(8) NOT NULL,
  `path` varchar(255) NOT NULL DEFAULT '',
  `path_ids` varchar(50) DEFAULT NULL,
  `full_path_ids` varchar(50) DEFAULT NULL,
  `creation_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_url`),
  KEY `idx_url_type` (`type`),
  KEY `idx_url_active` (`active`),
  KEY `idx_url_lang` (`lang`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('4', '7', 'page', '1', '1', 'sk', 'slideshow', '7', '7', '2015-05-20 15:18:41');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('5', '5', 'article', '1', '1', 'sk', 'slideshow/oznam-cafeteria', '7/5', '7/5', '2015-05-20 15:20:14');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('6', '6', 'article', '1', '1', 'sk', 'slideshow/dobrovonicky-de-v-oaze', '7/6', '7/6', '2015-05-20 15:22:59');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('9', '10', 'page', '1', '1', 'sk', 'forum', '10', '10', '2015-05-20 15:36:33');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('11', '12', 'page', '1', '1', 'sk', 'dokumenty', '12', '12', '2015-05-20 15:36:59');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('12', '13', 'page', '1', '1', 'sk', 'galerie', '13', '13', '2015-05-20 15:37:08');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('13', '14', 'page', '1', '1', 'sk', 'kontakt', '14', '14', '2015-05-20 15:37:20');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('14', '4', 'page', '1', '1', 'sk', 'home', '4', '4', '2015-05-20 15:37:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('15', '15', 'page', '1', '1', 'sk', 'backoffice', '15', '15', '2015-05-22 10:33:37');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('16', '5', 'page', '1', '1', 'sk', 'backoffice/hr', '15/5', '15/5', '2015-05-22 10:34:02');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('17', '6', 'page', '1', '1', 'sk', 'backoffice/hr/nas-tim', '15/5/6', '15/5/6', '2015-05-22 10:34:02');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('18', '8', 'page', '1', '1', 'sk', 'backoffice/recruitment', '15/8', '15/8', '2015-05-22 10:34:24');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('19', '9', 'page', '1', '1', 'sk', 'backoffice/operations', '15/9', '15/9', '2015-05-22 10:35:24');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('20', '16', 'page', '1', '1', 'sk', 'backoffice/finance', '15/16', '15/16', '2015-05-22 10:36:05');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('21', '17', 'page', '1', '1', 'sk', 'backoffice/operations/reception', '15/9/17', '15/9/17', '2015-05-22 11:24:09');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('22', '18', 'page', '1', '1', 'sk', 'backoffice/operations/travel', '15/9/18', '15/9/18', '2015-05-22 11:24:29');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('23', '19', 'page', '1', '1', 'sk', 'backoffice/operations/ito', '15/9/19', '15/9/19', '2015-05-22 11:24:40');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('37', '22', 'page', '1', '1', 'sk', 'backoffice/operations/team', '15/9/22', '15/9/22', '2015-05-25 14:45:50');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('38', '23', 'page', '1', '1', 'sk', 'backoffice/operations/purchasing', '15/9/23', '15/9/23', '2015-05-25 14:46:24');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('39', '24', 'page', '1', '1', 'sk', 'backoffice/operations/logistics', '15/9/24', '15/9/24', '2015-05-25 14:47:06');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('45', '25', 'page', '1', '1', 'sk', 'backoffice/recruitment/team', '15/8/25', '15/8/25', '2015-05-25 14:49:49');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('46', '26', 'page', '1', '1', 'sk', 'backoffice/recruitment/referral-fee', '15/8/26', '15/8/26', '2015-05-25 14:50:20');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('47', '27', 'page', '1', '1', 'sk', 'backoffice/recruitment/vitajte-v-ness', '15/8/27', '15/8/27', '2015-05-25 14:50:42');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('48', '28', 'page', '1', '1', 'sk', 'events', '28', '28', '2015-05-26 08:24:22');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('49', '14', 'article', '1', '1', 'sk', 'events/all-staff', '28/14', '28/14', '2015-05-26 08:26:49');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('50', '15', 'article', '1', '1', 'sk', 'events/pivo', '28/15', '28/15', '2015-05-26 08:27:29');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('51', '16', 'article', '1', '1', 'sk', 'slideshow/oznam-cafeteria-2', '7/16', '7/16', '2015-05-26 08:52:10');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('53', '11', 'page', '1', '1', 'sk', 'aj-ty', '11', '11', '2015-05-26 10:54:51');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('58', '20', 'page', '1', '1', 'sk', 'backoffice/recruitment/volne-pozicie', '15/8/20', '15/8/20', '2015-05-28 14:28:11');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('59', '10', 'article', '1', '1', 'sk', 'backoffice/recruitment/volne-pozicie/front-end-javascript-developer', '15/8/20/10', '15/8/20/10', '2015-05-28 14:28:11');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('60', '11', 'article', '1', '1', 'sk', 'backoffice/recruitment/volne-pozicie/c-senior-developer', '15/8/20/11', '15/8/20/11', '2015-05-28 14:28:11');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('61', '12', 'article', '1', '1', 'sk', 'backoffice/recruitment/volne-pozicie/oracle-database-specialist', '15/8/20/12', '15/8/20/12', '2015-05-28 14:28:11');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('62', '13', 'article', '1', '1', 'sk', 'backoffice/recruitment/volne-pozicie/python-developer', '15/8/20/13', '15/8/20/13', '2015-05-28 14:28:11');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('63', '21', 'page', '1', '1', 'sk', 'news', '21', '21', '2015-05-28 15:19:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('64', '7', 'article', '1', '1', 'sk', 'news/timesheets', '21/7', '21/7', '2015-05-28 15:19:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('65', '8', 'article', '1', '1', 'sk', 'news/garaz-na-bicykle', '21/8', '21/8', '2015-05-28 15:19:47');
INSERT INTO `url` (`id_url`, `id_entity`, `type`, `canonical`, `active`, `lang`, `path`, `path_ids`, `full_path_ids`, `creation_date`) VALUES ('66', '9', 'article', '1', '1', 'sk', 'news/special-referral-fee', '21/9', '21/9', '2015-05-28 15:19:47');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_role` smallint(4) unsigned NOT NULL,
  `join_date` timestamp NULL DEFAULT NULL,
  `last_visit` timestamp NULL DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `screen_name` varchar(50) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthdate` datetime DEFAULT NULL,
  `gender` smallint(1) DEFAULT NULL COMMENT '1: Male, 2 : Female',
  `password` varchar(255) NOT NULL,
  `email` varchar(120) NOT NULL,
  `salt` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `username` (`username`),
  KEY `id_role` (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id_user`, `id_role`, `join_date`, `last_visit`, `username`, `screen_name`, `firstname`, `lastname`, `birthdate`, `gender`, `password`, `email`, `salt`) VALUES ('1', '1', '2015-05-20 13:38:39', '2015-05-28 13:40:00', 'marek.boros@ness.com', 'Marek Boroš', 'Marek', 'Boroš', NULL, NULL, 'uxoJ4+mJ56BOiIS9DWv80bI=', 'marek.boros@ness.com', 'ce2eed574c662a0d');


